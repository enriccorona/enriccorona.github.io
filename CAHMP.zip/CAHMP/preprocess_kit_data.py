import glob
import c3d
import numpy as np

class_ = 'lean'
files = glob.glob('raw_data/*.c3d')
allsequences_joints = []
allsequences_isobject = []
allsequences_bboxes = []
allsequences_objects = []
allsequences_files = []

for file_ in files:
    if class_ not in file_:
        continue
    allpoints = []
    with open(file_, 'rb') as handle:
        reader = c3d.Reader(handle)
        labels = reader.point_labels

        for i, info in enumerate(reader.read_frames()):
            j, points, analog = info
            allpoints.append(points)

    allpoints = np.array(allpoints)

    objects = []
    vicons_objects = []
    vicons_names = []

    for i in range(len(labels)):
        lab = str.split(str(labels[i]), ':')
        if len(lab) < 2: # Correct format is object_name:position_marker. Errors have no ':' character
            continue
        if lab[0] not in objects:
            objects.append(lab[0])
            vicons_objects.append([i])
            vicons_names.append([str.replace(lab[1], ' ', '')]) # Replace helps removing spaces at the end
        else:
            ind = np.where(np.array(objects) == lab[0])[0][0]
            vicons_objects[ind].append(i)
            vicons_names[ind].append(str.replace(lab[1], ' ', ''))

    people_joints = ['RBHD', 'LBHD', 'LFHD', 'RFHD', # HEAD
                     'C7', 'T10', # TORSO
                     'RSHO', 'LSHO', 'RAOL', 'LAOL', 'RWTS', 'LWTS', # ARMS
                     'RHIP', 'LHIP', 'RKNE', 'LKNE', 'RHEE', 'LHEE', 'RMT5', 'LMT5' # LEGS
                    ]
    valid_people_joints = [0, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]

    all_person_joints = []
    bounding_boxes = []
    is_object_people = []
    for i in range(len(objects)):
        bboxes = []
        try:
            if 'subj' not in objects[i]:
                person = int(objects[i])
            # Person successfully identified! Obtain 3d bounding box and joints

            # Identifying only the relevant joints in the data:
            people_joints_inds = []
            for j in range(len(people_joints)):
                ind = np.where(np.array(vicons_names[i]) == people_joints[j])[0][0]
                people_joints_inds.append(vicons_objects[i][ind])
            people_joints_inds = np.array(people_joints_inds)

            person_joints = []
            for j in range(len(allpoints)):
                joints = allpoints[j, people_joints_inds, :3]
                person_joints.append(joints)
            person_joints = np.array(person_joints)

            # Mean of RBHD and LHBD, and mean of LFHD and RFHD to get central position of head
            person_joints[:, 0, :] = (person_joints[:, 0, :] + person_joints[:, 1, :])/2
            person_joints[:, 2, :] = (person_joints[:, 2, :] + person_joints[:, 3, :])/2
            person_joints = person_joints[:, valid_people_joints, :]

            all_person_joints.append(person_joints)

            is_object_people.append(1)
        except:
            # No person! Obtain 3d bounding box
            is_object_people.append(0)

        for j in range(len(allpoints)):
            points = allpoints[j, vicons_objects[i], :3]
            bbmin = points.min(0)
            bbmax = points.max(0)
            bboxes.append(np.concatenate((bbmin, bbmax)))
        bounding_boxes.append(bboxes)

    bounding_boxes = np.array(bounding_boxes)
    bounding_boxes = np.transpose(bounding_boxes, (1, 0, 2))
    all_person_joints = np.array(all_person_joints)
    is_object_people = np.array(is_object_people)

    #NOTE: No series with more than one person, so let's go straight removing that dimension
    allsequences_joints.append(all_person_joints[0])
    #allsequences_joints.append(all_person_joints)
    allsequences_isobject.append(is_object_people)
    allsequences_bboxes.append(bounding_boxes)
    allsequences_objects.append(objects)
    allsequences_files.append(file_)

allsequences_joints = np.array(allsequences_joints)
allsequences_isobject = np.array(allsequences_isobject)
allsequences_bboxes = np.array(allsequences_bboxes)
allsequences_objects = np.array(allsequences_objects)
allsequences_files = np.array(allsequences_files)

np.save('files_' + str(class_) + '.npy', allsequences_files)
np.save('objects_' + str(class_) + '.npy', allsequences_objects)
np.save('joints_' + str(class_) + '.npy', allsequences_joints)
np.save('isobject_' + str(class_) + '.npy', allsequences_isobject)
np.save('bbxes_' + str(class_) + '.npy', allsequences_bboxes)
