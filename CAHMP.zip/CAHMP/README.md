# Context-Aware Human Motion Prediction
[[Project]](https://www.iri.upc.edu/people/ecorona/ca_hmp/)[ [Paper]](https://arxiv.org/pdf/1904.03419.pdf)

<img src='https://www.iri.upc.edu/people/ecorona/ca-hmp/banner.png' align="right" width=1000 style="margin-bottom:30px;">


&nbsp;
&nbsp;
## Prerequisites
- Pytorch (Tested with version 1.2)
- Data: This release just contains a preprocessed section of the dataset, obtained using the preprocessing script ```preprocess_kit_dataset.py```.

# Model

<img src='images/model.png' align="right" width=1000 style="margin-bottom:30px;">

We use a semantic-graph model where the nodes parameterize the human and objects in the scene and the edges their mutual interactions. These interactions are iteratively learned through a graph attention layer, fed with the past observations, which now include both object and human body motions. Once this semantic graph is learned, we inject it to a standard RNN to predict future movements of the human/sand object/s.

## Train:
The training on the sample dataset takes around 8 hours with the sample data. The stochasticity of the training process makes that different models can have different performance. The released model has better performance than stated in the paper. The model can be trained using the following command

```python train.py --name model_lean --seq_length_in 100 --seq_length_out 200 --seq_step 10 --lr_G 0.0001```

## Test:
The models are evaluated using both quantitative and qualitative metrics. For the qualitative evaluation, the script only shows different adjacency matrices predicted for different scenarios. More understandable visualizations will come soon.

### Checkout quantitative results
```python test_quantitatively.py --name model_lean --seq_length_in 100 --seq_length_out 200 --seq_step 10 --load_epoch 8```

### Checkout adjacency matrix predicted

```python test_qualitatively.py --name model_lean --seq_length_in 100 --seq_length_out 200 --seq_step 10 --load_epoch 8 --batch_size 1```

### Citation
If you use this code or ideas from the paper for your research, please cite our paper:
```
@inproceedings{corona2020context,
  title={Context-aware Human Motion Prediction},
  author={Corona, Enric and Pumarola, Albert and Alenya, Guillem and Moreno-Noguer, Francesc},
  booktitle={Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition},
  pages={6992--7001},
  year={2020}
}
```
