import time
import utils
from options.test_options import TestOptions
from data.custom_dataset_data_loader import CustomDatasetDataLoader
from models.models import ModelsFactory
from utils.tb_visualizer import TBVisualizer
from collections import OrderedDict
import os
import numpy as np

class Test:
    def __init__(self):

        self._opt = TestOptions().parse()
        #assert self._opt.load_epoch > 0, 'Use command --load_epoch to indicate the epoch you want to load - and choose a trained model'

        data_loader_test = CustomDatasetDataLoader(self._opt, mode='test')
        self._dataset_test = data_loader_test.load_data()
        self._dataset_test_size = len(data_loader_test)
        print('#test images = %d' % self._dataset_test_size)

        self._model = ModelsFactory.get_by_name(self._opt.model, self._opt)
        self._tb_visualizer = TBVisualizer(self._opt)

        self._total_steps = self._dataset_test_size
        self._display_visualizer_test(20, self._total_steps)

    def _display_visualizer_test(self, i_epoch, total_steps):
        test_start_time = time.time()
        threshold_visuals =-1

        # set model to eval
        self._model.set_eval()

        # evaluate self._opt.num_iters_validate epochs
        test_errors = OrderedDict()
        statistics = OrderedDict()
        start_iter = 45 # More interesting test sample with 3 objects
        iter_step = 50 # Test samples are consecutive in sequence, so let's just jump over few of them to get representative difference in the adjacency matrix predicted
        iters = 20
        all_interactions = []
        numobjs = []
        for i_test_batch, test_batch in enumerate(self._dataset_test):
            if i_test_batch < start_iter:
                continue
            if i_test_batch > start_iter + iters:
                break
            # evaluate model
            self._model.set_input(test_batch)
            self._model.forward(keep_data_for_visuals=(i_test_batch < threshold_visuals), obtain_errors=True)

            interactions_predicted = self._model._interactions_predicted[0]
            print("Adjacency matrix in first step")
            print(interactions_predicted[0].cpu().tolist())
            print("Last Adjacency matrix predicted")
            print(interactions_predicted[-1].cpu().tolist())
            print("")

if __name__ == "__main__":
    Test()
