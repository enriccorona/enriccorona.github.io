from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

#from tensorflow.python.ops import array_ops
#from tensorflow.python.ops import variable_scope as vs

import random

import numpy as np
import os
from six.moves import xrange  # pylint: disable=redefined-builtin
import torch
from torch import nn
import torch.nn.functional as F
#import rnn_cell_extensions # my extensions of the tf repos
import math
import skimage.io
import glob
from torch.autograd import Variable
from .networks import NetworkBase

use_cuda=True
use_cpu = not use_cuda

class Seq2SeqModel(NetworkBase):
  def __init__(self,
               source_seq_len,
               target_seq_len,
               rnn_size, # hidden recurrent layer size
               num_layers,
      #         max_gradient_norm,
               dropout=0.0,
               context_size=32,
               human_size=34,
               nfeat=64,
               nhid=256,
               use_bias=False,
               dtype=torch.float32):

    super(Seq2SeqModel, self).__init__()

    self.HUMAN_SIZE = human_size
    self.context_size = context_size #32

    # Summary writers for train and test runs
    self.source_seq_len = source_seq_len
    self.target_seq_len = target_seq_len
    self.rnn_size = rnn_size
    self.context_rnn_size = rnn_size//4
    self.dropout = dropout
    self.nfeat = nfeat
    self.nhid = nhid

    # === Create the RNN that will keep the state ===
    print('rnn_size = {0}'.format( rnn_size ))
    self.cell = torch.nn.GRUCell(self.HUMAN_SIZE, self.rnn_size)
    self.context_cell = torch.nn.GRUCell(self.context_size, self.nhid)#self.context_rnn_size)

    self.fc_human = nn.Linear(self.rnn_size+self.nhid, self.HUMAN_SIZE)
    #self.fc_human = nn.Linear(self.rnn_size+self.context_rnn_size, self.HUMAN_SIZE)
    self.fc_objects = nn.Linear(self.nhid, 6)
    #self.fc_objects = nn.Linear(, 6)

    from .GCN_layers import GraphConvolution

    #self.gc1 = GraphConvolution(nfeat, nfeat, bias=use_bias)
    #self.gc2 = GraphConvolution(nfeat, nfeat, bias=use_bias)

    self.ec1 = nn.Conv1d(nfeat*2, nfeat, kernel_size=1, bias=use_bias)
    self.gru = nn.GRU(nfeat, nhid)
    self.dropout = dropout

    self.conv_gc1 = nn.Conv2d(nhid*2, nhid, 1, bias=False)
    self.conv_gc2 = nn.Conv2d(nhid, 1, 1, bias=False)
    self.nfeat = nfeat
    self.nhid = nhid

  def forward(self, encoder_inputs, representations, isperson):
    lenseq = len(representations)
    numobjs = len(representations[0])

    # NOTE: DETERMINISTIC:
    #hidden_states = torch.zeros([1, numobjs, self.nhid]).cuda()

    # NOTE: ADDING GAUSSIAN NOISE z
    hidden_states = torch.randn([1, numobjs, self.nhid]).cuda()/10
    adjs = torch.eye(numobjs).cuda()
    motion_state = torch.zeros(isperson.sum(), 1, self.rnn_size).cuda()
    inds_person = np.where(isperson)[0]

    encoder_inputs = encoder_inputs.unsqueeze(1)

    all_adjs = []
    outputs = []
    predicted_representations = []
    prev = None
    obj_classes = representations[0, :, 6:-18*3]

    ## PAST
    for step in range(lenseq-1):
        # PREDICT INTERACTIONS:
        if step > 0: #TODO: COULD START PREDICTING ADJs LATER? AFTER RNN UNDERSTANDS BETTER OBJ. MOVEMENT?
            adjs = self.predict_adjs(hidden_states, numobjs, isperson)

        # ENCODE PAST CONTEXT:
        obj_hidden_repr = self.obtain_hidden_context_representation(representations[step], adjs, numobjs)
        _, hidden_states = self.gru(obj_hidden_repr.view([1, numobjs, -1]), hidden_states)
        all_adjs.append(adjs)

        # ENCODE PAST MOTION FOR ALL HUMANS IN SCENE:
        new_motion_state = []
        for j in range(len(inds_person)):
            state = self.cell(representations[step, inds_person[j], -18*3:].unsqueeze(0), motion_state[j])
            new_motion_state.append(state)
        motion_state = torch.stack(new_motion_state).cuda()

    ## FUTURE:
    current_representation = representations[-1]
    for step in range(self.target_seq_len):

        # PREDICT INTERACTIONS:
        adjs = self.predict_adjs(hidden_states, numobjs, isperson)

        # ENCODE FUTURE CONTEXT:
        obj_hidden_repr = self.obtain_hidden_context_representation(current_representation, adjs, numobjs)
        _, hidden_states = self.gru(obj_hidden_repr.view([1, numobjs, -1]), hidden_states)
        all_adjs.append(adjs)

        # ENCODE PAST MOTION FOR ALL HUMANS IN SCENE:
        new_motion_state = []
        preds = []
        for j in range(len(inds_person)):
            inp = current_representation[inds_person[j], -18*3:].unsqueeze(0)
            state = self.cell(inp, motion_state[j])
            new_motion_state.append(state)
            all_states = torch.cat((motion_state[j], hidden_states[0, inds_person[j]].unsqueeze(0)), dim=1)
            output = inp[:,:self.HUMAN_SIZE] + self.fc_human(all_states)
            preds.append(output.view(-1))
        preds = torch.stack(preds)
        outputs.append(preds)
        motion_state = torch.stack(new_motion_state).cuda()

        # DECODE FUTURE CONTEXT:
        nextmoves = []
        for j in range(numobjs):
            nextmove = current_representation[j, :6] + self.fc_objects(hidden_states[0, j])
            nextmoves.append(nextmove)
        nextmoves = torch.stack(nextmoves)

        # BUILD NEXT REPRESENTATION:
        next_joints = torch.cat((torch.zeros(np.argmax(isperson), 18*3).cuda(), preds), 0)
        if isperson[-1] == 0:
            next_joints = torch.cat((next_joints, torch.zeros(numobjs- np.argmax(isperson)-1, 18*3).cuda()))
        current_representation = torch.cat((nextmoves, obj_classes, next_joints), 1)
        predicted_representations.append(current_representation)

    return torch.stack(outputs), torch.stack(predicted_representations), torch.stack(all_adjs)

  def predict_adjs(self, hidden_states, numobjs, isperson=None):
      adjs = torch.zeros([1, self.nhid*2, numobjs, numobjs])
      adjs = adjs.cuda()
      adjs = Variable(adjs)
      difference = hidden_states.unsqueeze(2) - hidden_states.unsqueeze(1)
      absolute = hidden_states.unsqueeze(2).repeat(1, 1, numobjs, 1).permute(0,3,1,2)

      adjs = torch.cat((absolute, difference.permute(0,3,1,2)), 1)
      adjs = F.relu(self.conv_gc1(adjs))
      adjs = self.conv_gc2(adjs)
      adjs = nn.Softmax(-1)(adjs).squeeze(0).squeeze(0)

      return adjs

  def obtain_hidden_context_representation(self, representations, adjs, numobjs):
    # NOTE: USE GCNs:
    #pred = self.gc1(representations, adjs)
    #pred = self.gc2(pred, adjs)
    # NOTE: JUST USE SIMPLE MATRIX MULTIPLICATIONS:
    #pred = torch.spmm(adjs, representations[step])
    #pred = torch.spmm(adjs, pred)
    # NOTE: USE EDGECONVs:
    # EFFICIENT WAY:
    difference = representations.unsqueeze(0) - representations.unsqueeze(1)
    absolute = representations.unsqueeze(1).repeat(1, numobjs, 1)

    net_input = torch.cat((absolute, difference), -1).transpose(2,1)
    pred = self.ec1(net_input).transpose(2,1)
    pred = F.relu((pred*adjs.unsqueeze(-1)).sum(1))

    # SLOW WAY:
    #pred = torch.zeros([numobjs, self.nfeat]).cuda()
    #for j in range(numobjs):
    #    for k in range(numobjs):
    #        pred[j] = pred[j] + adjs[j, k]*self.ec1(torch.cat((representations[j, :], representations[j, :] - representations[k, :])))
    #pred = F.relu(pred)

    return pred

