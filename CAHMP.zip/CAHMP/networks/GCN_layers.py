import math

import torch

from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
import numpy as np
from .networks import NetworkBase

class GraphConvolution(Module):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """

    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, x, adj):
        if len(x.shape) == 3:
            support = torch.einsum('bxy,yk->bxk', (x, self.weight))
            output = torch.einsum('bxy,byk->bxk', (adj, support))
        else:
            support = torch.mm(x, self.weight)
            output = torch.spmm(adj, support)
        
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


class graph_model_edgeconv_givenadj(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(graph_model_edgeconv_givenadj, self).__init__()
        self.secondtime = secondtime
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        print("REMEMBER WE\'RE USING A SLIGHTLY MODIFIED VERSION OF THE GRAPH MODEL!! ONLY ONE GRAPH LAYER DIRECTLY TO nout")
        #self.gc1 = GraphConvolution(nfeat, nout, bias=use_bias)
        #self.gc1 = nn.Linear(nfeat*2, nout, bias=use_bias)
        self.ec1 = nn.Linear(nfeat*2, nhid, bias=use_bias)
        self.ec2 = nn.Linear(nhid*2, nout, bias=use_bias)
        self.dropout = dropout

        self.conv_gc1 = nn.Conv2d(nfeat*2, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, adjs, sizes):
        out_rep1 = []
        for i in range(len(x)):
            rep = []
        #    for j in range(sizes[i]):
        #        feats = []
        #        for k in range(sizes[i]):
        #            #adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])
        #            feats.append(torch.cat([x[i][j], x[i][j] - x[i][k]]))
        #        feats = torch.stack(feats)
        #        feats = self.ec1(feats)
        #        feats = torch.matmul(adjs[i, j], feats)
        #        # Otherwise, trivial way is to reshape adj and repeat value in second dimension, multiply it by feats and mean(0) or sum(0)
        #        rep.append(feats)
        #    out_rep1.append(torch.stack(rep))
        out_rep1 = torch.stack(out_rep1)
        return out_rep1, adjs



class recurrent_graph_model_givenadjs(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(recurrent_graph_model_givenadjs, self).__init__()

        #self.ec1 = nn.Linear(nfeat*2, nfeat, bias=use_bias)
        self.gc1 = GraphConvolution(nfeat, nfeat, bias=use_bias)
        self.gc2 = GraphConvolution(nfeat, nfeat, bias=use_bias)
        self.gru = nn.GRU(nfeat, nhid)
        #self.ec2 = nn.Linear(nhid*2, nout, bias=use_bias)
        self.dropout = dropout

        #self.conv_gc1 = nn.Conv2d(nhid*2, 1, 1, bias=False)
        self.conv_gc1 = nn.Conv2d(nhid*2, nhid, 1, bias=False)
        self.conv_gc2 = nn.Conv2d(nhid, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, adjs, sizes, get_adj=False):
        # NOTE THIS NETWORK SHOULD BE USEFUL TO IMPROVE GENERAL ARCHITECTURE OF THE CONTEXT

        # adjs shape should be [numobjs, numobjs]
        lenseq = len(x)
        numobjs = sizes[0]
        
        hidden_states = torch.zeros([1, numobjs, self.nhid]).cuda()

        for step in range(lenseq):
            #new_hidden_states = []
            #suma = torch.zeros([self.nfeat]).cuda()
            #for j in range(numobjs):
            #    for k in range(numobjs):
            #        #suma = suma + adjs[j, k]*x[step, k, :]
            #        # NOTE: WITH EDGE CONVOLUTION:
            ##        suma = suma + adjs[j, k]*self.ec1(torch.cat((x[step, j, :], x[step, k, :])))
            #    _, out = self.gru(suma.view([1,1,-1]), hidden_states[j].view([1,1,-1]))
            #    new_hidden_states.append(out[0, 0])
            #hidden_states = new_hidden_states

            suma = self.gc1(x[step], adjs)
            suma = self.gc2(suma, adjs)
            #output = torch.spmm(adjs, x[step])
            #output = torch.spmm(adjs, output)
            #new_hidden_states = []
#            for j in range(numobjs):
#                _, out = self.gru(suma[j].view([1, 1, -1]), hidden_states[j].view([1,1,-1]))
#                new_hidden_states.append(out[0, 0])
#            hidden_states = new_hidden_states
#
            _, hidden_states = self.gru(suma.view([1, numobjs, -1]), hidden_states)

#            new_hidden_states = []
#            for j in range(numobjs):

        return hidden_states[0], adjs
        #return torch.stack(hidden_states), adjs



class recurrent_graph_model(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(recurrent_graph_model, self).__init__()
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        print("REMEMBER WE\'RE USING A SLIGHTLY MODIFIED VERSION OF THE GRAPH MODEL!! ONLY ONE GRAPH LAYER DIRECTLY TO nout")
        #self.gc1 = GraphConvolution(nfeat, nout, bias=use_bias)
        #self.gc1 = nn.Linear(nfeat*2, nout, bias=use_bias)
        #self.gc1 = nn.Linear(nfeat*2, nout, bias=use_bias)
        #self.ec1 = nn.Linear(12, nfeat, bias=use_bias)
        self.ec1 = nn.Linear(nfeat*2, nfeat, bias=use_bias)
        self.gru = nn.GRU(nfeat, nhid)
        #self.ec2 = nn.Linear(nhid*2, nout, bias=use_bias)
        self.dropout = dropout

        #self.conv_gc1 = nn.Conv2d(nhid*2, 1, 1, bias=False)
        self.conv_gc1 = nn.Conv2d(nhid*2+15*2, nhid, 1, bias=False)
        #self.conv_gc1 = nn.Conv2d(nhid*2, nhid, 1, bias=False)
        self.conv_gc2 = nn.Conv2d(nhid, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=False):
        lenseq = len(x)
        numobjs = sizes[0]
        
        hidden_states = torch.zeros([1, numobjs, self.nhid]).cuda()
        adjs = torch.eye(numobjs)

        all_adjs = []
        for step in range(lenseq):
            if step > 0: #TODO: COULD BE LATER
                adjs = torch.zeros([1, self.nhid*2+30, numobjs, numobjs])
                #adjs = torch.zeros([1, self.nhid*2, numobjs, numobjs])
                adjs = adjs.cuda()
                adjs = Variable(adjs)
                for j in range(numobjs):
                    for k in range(numobjs):
                        #adjs[0, :, j, k] = torch.cat([hidden_states[0, j], hidden_states[0, j]-hidden_states[0, k]])
                        adjs[0, :, j, k] = torch.cat([hidden_states[0, j], hidden_states[0, j]-hidden_states[0, k], x[0, j, 6:], x[0, k, 6:]])

                adjs = F.relu(self.conv_gc1(adjs))
                adjs = self.conv_gc2(adjs)
                adjs = nn.Softmax(-1)(adjs).squeeze(0).squeeze(0)

#            new_hidden_states = []
#
#            for j in range(numobjs):
#                suma = torch.zeros([self.nfeat]).cuda()
#                for k in range(numobjs):
#                    #suma = suma + adjs[j, k]*x[step, k, :]
#                    # NOTE: WITH EDGE CONVOLUTION:
#                    suma = suma + adjs[j, k]*self.ec1(torch.cat((x[step, j, :], x[step, j, :] - x[step, k, :])))
#                    #suma = suma + adjs[j, k]*self.ec1(torch.cat((x[step, j, :], x[step, k, :])))
#                _, out = self.gru(suma.view([1,1,-1]), hidden_states[j].view([1,1,-1]))
#                new_hidden_states.append(out[0, 0])
#            hidden_states = new_hidden_states
#                #hidden_states[j] = out[0,0]

            _, hidden_states = self.gru(output.view([1, numobjs, -1]), hidden_states)
            all_adjs.append(adjs)

        return torch.stack(hidden_states), adjs
        #return torch.stack(hidden_states), torch.stack(all_adjs)


class recurrent_graph_model_doubleedgeconv(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(recurrent_graph_model_doubleedgeconv, self).__init__()
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        print("USING DOUBLE EDGE CONV MODEL")
        self.gc1 = GraphConvolution(nfeat, nfeat, bias=use_bias)
        self.gc2 = GraphConvolution(nfeat, nfeat, bias=use_bias)

        self.ec1 = nn.Linear(nfeat*2, nfeat, bias=use_bias)
        self.gru = nn.GRU(nfeat, nhid)
        self.ec2 = nn.Linear(nfeat*2, nfeat, bias=use_bias)
        self.dropout = dropout

        self.conv_gc1 = nn.Conv2d(nhid*2, nhid, 1, bias=False)
        self.conv_gc2 = nn.Conv2d(nhid, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=False):
        lenseq = len(x)
        numobjs = sizes[0]
        
        # NOTE: DETERMINISTIC:
        #hidden_states = torch.zeros([1, numobjs, self.nhid]).cuda()

        # NOTE: ADDING GAUSSIAN NOISE z
        hidden_states = torch.randn([1, numobjs, self.nhid]).cuda()/10
        adjs = torch.eye(numobjs).cuda()

        all_adjs = []
        for step in range(lenseq):
            if step > 0: #TODO: COULD BE LATER
                #adjs = torch.zeros([1, self.nhid*2+30, numobjs, numobjs])
                adjs = torch.zeros([1, self.nhid*2, numobjs, numobjs])
                adjs = adjs.cuda()
                adjs = Variable(adjs)
                for j in range(numobjs):
                    for k in range(numobjs):
                        adjs[0, :, j, k] = torch.cat([hidden_states[0, j], hidden_states[0, j]-hidden_states[0, k]])
                        #adjs[0, :, j, k] = torch.cat([hidden_states[j], hidden_states[j]-hidden_states[k], x[0, j, 6:], x[0, k, 6:]])

                adjs = F.relu(self.conv_gc1(adjs))
                adjs = self.conv_gc2(adjs)
                adjs = nn.Softmax(-1)(adjs).squeeze(0).squeeze(0)

            # NOTE: USE GCNs:
            #suma = self.gc1(x[step], adjs)
            #suma = self.gc2(suma, adjs)
            # NOTE: JUST USE SIMPLE MULTIPLICATIONS:
            #output = torch.spmm(adjs, x[step])
            #output = torch.spmm(adjs, output)
            # NOTE: USE EDGECONVs:
            suma = torch.zeros([numobjs, self.nfeat]).cuda()
            for j in range(numobjs):
                for k in range(numobjs):
                    suma[j] = suma[j] + adjs[j, k]*self.ec1(torch.cat((x[step, j, :], x[step, j, :] - x[step, k, :])))
            suma = F.relu(suma)
        #    suma2 = torch.zeros([numobjs, self.nfeat]).cuda()
        #    for j in range(numobjs):
        #        for k in range(numobjs):
        #            suma2[j] = suma2[j] + adjs[j, k]*self.ec2(torch.cat((suma[j], suma[j] - suma[k])))
        #    # NOTE: COMMON PART
            _, hidden_states = self.gru(suma.view([1, numobjs, -1]), hidden_states)
            all_adjs.append(adjs)

        #return hidden_states[0], adjs
        return hidden_states[0], torch.stack(all_adjs)


class recurrent_graph_model_fakeadjs(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(recurrent_graph_model_fakeadjs, self).__init__()
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        print("USING DOUBLE EDGE CONV MODEL")
        self.gc1 = GraphConvolution(nfeat, nfeat, bias=use_bias)
        self.gc2 = GraphConvolution(nfeat, nfeat, bias=use_bias)

        self.ec1 = nn.Linear(nfeat*2, nfeat, bias=use_bias)
        self.gru = nn.GRU(nfeat, nhid)
        self.ec2 = nn.Linear(nfeat*2, nfeat, bias=use_bias)
        self.dropout = dropout

        self.conv_gc1 = nn.Conv2d(nhid*2, nhid, 1, bias=False)
        self.conv_gc2 = nn.Conv2d(nhid, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, adjs=None):
        # WAY 1: GIVING BINARY ADJACENCIES DON'T PRODUCE GOOD RESULTS REALLY WHEN THE MODEL IS NOT TRAINED WITH THAT
        # WAY 2: ADDING BIAS TO ONE OF THE INTERACTIONS ONLY, ADDING 1
        if adjs is None:
            predictadjs = True
        else:
            givenadjs = adjs
            predictadjs = False

        lenseq = len(x)
        numobjs = sizes[0]
        
        # NOTE: DETERMINISTIC:
        #hidden_states = torch.zeros([1, numobjs, self.nhid]).cuda()

        # NOTE: ADDING GAUSSIAN NOISE z
        hidden_states = torch.randn([1, numobjs, self.nhid]).cuda()/10
        adjs = torch.eye(numobjs).cuda()

        all_adjs = []
        for step in range(lenseq):
            if step > 0: #TODO: COULD BE LATER
                #adjs = torch.zeros([1, self.nhid*2+30, numobjs, numobjs])
                adjs = torch.zeros([1, self.nhid*2, numobjs, numobjs])
                adjs = adjs.cuda()
                adjs = Variable(adjs)
                for j in range(numobjs):
                    for k in range(numobjs):
                        adjs[0, :, j, k] = torch.cat([hidden_states[0, j], hidden_states[0, j]-hidden_states[0, k]])
                        #adjs[0, :, j, k] = torch.cat([hidden_states[j], hidden_states[j]-hidden_states[k], x[0, j, 6:], x[0, k, 6:]])

                adjs = F.relu(self.conv_gc1(adjs))
                adjs = self.conv_gc2(adjs)
                    
                adjs = nn.Softmax(-1)(adjs).squeeze(0).squeeze(0)
                if not predictadjs:
                    length = len(givenadjs)
                    for j in range(length):
                        val = torch.max(givenadjs[j])
                        if val == 0:
                            continue
                        inds = np.arange(len(givenadjs))
                        ind = torch.argmax(givenadjs[j]).cpu()
                        inds = np.delete(inds, ind)
                        adjs[j, ind] = val
                        adjs[j, inds] = adjs[j, inds]*(1-val)/adjs[j, inds].sum()

                    #rang = adjs.max() - adjs.min()
                    #adjs = adjs + rang*givenadjs

            # NOTE: USE GCNs:
            suma = self.gc1(x[step], adjs)
            #suma = self.gc2(suma, adjs)
            # NOTE: JUST USE SIMPLE MULTIPLICATIONS:
            #output = torch.spmm(adjs, x[step])
            #output = torch.spmm(adjs, output)
            # NOTE: USE EDGECONVs:
            #suma = torch.zeros([numobjs, self.nfeat]).cuda()
            #for j in range(numobjs):
            #    for k in range(numobjs):
            #        suma[j] = suma[j] + adjs[j, k]*self.ec1(torch.cat((x[step, j, :], x[step, j, :] - x[step, k, :])))
            #suma = F.relu(suma)
        #    suma2 = torch.zeros([numobjs, self.nfeat]).cuda()
        #    for j in range(numobjs):
        #        for k in range(numobjs):
        #            suma2[j] = suma2[j] + adjs[j, k]*self.ec2(torch.cat((suma[j], suma[j] - suma[k])))
        #    # NOTE: COMMON PART
            _, hidden_states = self.gru(suma.view([1, numobjs, -1]), hidden_states)
            all_adjs.append(adjs)

        #return hidden_states[0], adjs
        if not predictadjs:
            print(givenadjs)
        return hidden_states[0], torch.stack(all_adjs)


class bayesian_recurrent_graph_model_doubleedgeconv(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(bayesian_recurrent_graph_model_doubleedgeconv, self).__init__()
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        print("USING BAYESIAN DOUBLE EDGE CONV MODEL")
        self.gc1 = GraphConvolution(nfeat, nfeat, bias=use_bias)
        self.gc2 = GraphConvolution(nfeat, nfeat, bias=use_bias)

        self.ec1 = nn.Linear(nfeat*2, nfeat, bias=use_bias)
        self.gru = nn.GRU(nfeat, nhid)
        self.ec2 = nn.Linear(nfeat*2, nfeat, bias=use_bias)
        self.dropout = dropout

        self.conv_gc1 = nn.Conv2d(nhid*2, nhid, 1, bias=False)
        self.conv_gc2 = nn.Conv2d(nhid, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=False, get_n_examples = 20):
        lenseq = len(x)
        numobjs = sizes[0]
        
        # NOTE: STUDY USE OF MC DROPOUT

        hidden_states = torch.randn([get_n_examples, numobjs, self.nhid]).cuda()
        #hidden_states = torch.randn([1, numobjs, self.nhid]).cuda()
        #hidden_states = torch.zeros([1, numobjs, self.nhid]).cuda()
        adjs = torch.eye(numobjs).unsqueeze(0).repeat(get_n_examples, 1, 1).cuda()

        all_adjs = []
        for step in range(lenseq):
            if step > 0: #TODO: TRY STARTING FROM ZERO! NOW WITH NOISE WILL GIVE INTERESTING ADJ MATRICES
                adjs = torch.zeros([get_n_examples, self.nhid*2, numobjs, numobjs])
                adjs = adjs.cuda()
                adjs = Variable(adjs)
                for j in range(numobjs):
                    for k in range(numobjs):
                        adjs[:, :, j, k] = torch.cat([hidden_states[:, j], hidden_states[:, j]-hidden_states[:, k]], 1)
                        #adjs[0, :, j, k] = torch.cat([hidden_states[j], hidden_states[j]-hidden_states[k], x[0, j, 6:], x[0, k, 6:]])

                adjs = F.relu(self.conv_gc1(adjs))
                adjs = self.conv_gc2(adjs)
                adjs = nn.Softmax(-1)(adjs).squeeze(1)

            # NOTE: USE GCNs:
            suma = self.gc1(x[step].unsqueeze(0).repeat(get_n_examples, 1, 1), adjs)
            #suma = self.gc2(suma, adjs)
            # NOTE: JUST USE SIMPLE MULTIPLICATIONS:
            #output = torch.spmm(adjs, x[step])
            #output = torch.spmm(adjs, output)
            # NOTE: USE EDGECONVs:
#            suma = torch.zeros([numobjs, self.nfeat]).cuda()
#            for j in range(numobjs):
#                for k in range(numobjs):
#                    suma[j] = suma[j] + adjs[j, k]*self.ec1(torch.cat((x[step, j, :], x[step, k, :])))

            # COMMON PART
            gru_input = suma.view([1, -1, self.nfeat])
            hidden_states = hidden_states.view([1, -1, self.nhid])
            _, hidden_states = self.gru(gru_input, hidden_states)
            hidden_states = hidden_states.view([get_n_examples, numobjs, self.nhid])
            all_adjs.append(adjs)

        #return hidden_states[0], adjs
        return hidden_states, torch.stack(all_adjs)


class recurrent_graph_model_nonlinearadjs(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(recurrent_graph_model_nonlinearadjs, self).__init__()
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        print("REMEMBER WE\'RE USING A SLIGHTLY MODIFIED VERSION OF THE GRAPH MODEL!! ONLY ONE GRAPH LAYER DIRECTLY TO nout")
        #self.gc1 = GraphConvolution(nfeat, nout, bias=use_bias)
        #self.gc1 = nn.Linear(nfeat*2, nout, bias=use_bias)
        self.ec1 = nn.Linear(nfeat*2, nfeat, bias=use_bias)
        self.gru = nn.GRU(nfeat, nhid)
        #self.ec2 = nn.Linear(nhid*2, nout, bias=use_bias)
        self.dropout = dropout

        #self.conv_gc1 = nn.Conv2d(nhid*2, 1, 1, bias=False)
        self.conv_gc1 = nn.Conv2d(nhid*2, nhid, 1, bias=False)
        self.conv_gc2 = nn.Conv2d(nhid, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=False):
        lenseq = len(x)
        numobjs = sizes[0]
        
        hidden_states = torch.zeros([numobjs, self.nhid]).cuda()
        adjs = torch.eye(numobjs)

        for step in range(lenseq):
            if step > 0: #TODO: COULD BE LATER
                adjs = torch.zeros([1, self.nhid*2, numobjs, numobjs])
                adjs = adjs.cuda()
                adjs = Variable(adjs)
                for j in range(numobjs):
                    for k in range(numobjs):
                        #adjs[0, :, j, k] = torch.cat([hidden_states[j], hidden_states[k]])
                        adjs[0, :, j, k] = torch.cat([hidden_states[j], hidden_states[j]-hidden_states[k]])
                        #adjs[0, :, j, k] = torch.cat([hidden_states[j]-hidden_states[k], hidden_states[j]-hidden_states[k]])
                   #     print(torch.cat([hidden_states[j], hidden_states[j]-hidden_states[k]]))

                adjs = F.relu(self.conv_gc1(adjs))
                adjs = F.relu(self.conv_gc2(adjs)).squeeze(0).squeeze(0)
                #adjs = nn.Softmax(-1)(adjs).squeeze(0).squeeze(0)
                #eps = torch.FloatTensor([1e-5])
                #eps = eps.cuda()
                #adjs = adjs + eps
                adjs = normalize_tensor(adjs)

            new_hidden_states = []
            suma = torch.zeros([self.nfeat]).cuda()
            for j in range(numobjs):
                for k in range(numobjs):
                    #suma = suma + adjs[j, k]*x[step, k, :]
                    # NOTE: WITH EDGE CONVOLUTION:
                    suma = suma + adjs[j, k]*self.ec1(torch.cat((x[step, j, :], x[step, k, :])))
                _, out = self.gru(suma.view([1,1,-1]), hidden_states[j].view([1,1,-1]))
                new_hidden_states.append(out[0, 0])
            hidden_states = new_hidden_states
                #hidden_states[j] = out[0,0]

        return torch.stack(hidden_states), adjs


class recurrent_graph_model_nonlinearadjs_more(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(recurrent_graph_model_nonlinearadjs_more, self).__init__()
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        self.ec1 = nn.Linear(nfeat*2, nfeat, bias=use_bias)
        self.gru = nn.GRU(nfeat, nhid)
        #self.ec2 = nn.Linear(nhid*2, nout, bias=use_bias)
        self.dropout = dropout

        #self.conv_gc1 = nn.Conv2d(nhid*2, 1, 1, bias=False)
        self.conv_gc1 = nn.Conv2d(nhid*2, nhid, 1, bias=False)
        self.conv_gc2 = nn.Conv2d(nhid, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=False):
        lenseq = len(x)
        numobjs = sizes[0]
        
        hidden_states = torch.zeros([numobjs, self.nhid]).cuda()
        adjs = torch.eye(numobjs)

        #all_adjs = []
        for step in range(lenseq):
            if step > 0: #TODO: COULD BE LATER
                adjs = torch.zeros([1, self.nhid*2, numobjs, numobjs])
                adjs = adjs.cuda()
                adjs = Variable(adjs)
                for j in range(numobjs):
                    for k in range(numobjs):
                        #adjs[0, :, j, k] = torch.cat([hidden_states[j], hidden_states[k]])
                        adjs[0, :, j, k] = torch.cat([hidden_states[j], hidden_states[j]-hidden_states[k]])
                        #adjs[0, :, j, k] = torch.cat([hidden_states[j]-hidden_states[k], hidden_states[j]-hidden_states[k]])
                   #     print(torch.cat([hidden_states[j], hidden_states[j]-hidden_states[k]]))

                adjs = F.relu(self.conv_gc1(adjs))
                adjs = F.relu(self.conv_gc2(adjs)).squeeze(0).squeeze(0)

                # IDEA: THIS CAN HAVE NEGATIVE SLOPE TO BE ABLE TO USE GRADIENTS? AND THEN ON VALIDATION/TEST JUST USE RELU?
                #adjs = F.leaky_relu(self.conv_gc2(adjs)).squeeze(0).squeeze(0)
 #           all_adjs.append(adjs)

            new_hidden_states = []
            suma = torch.zeros([self.nfeat]).cuda()
            for j in range(numobjs):
                for k in range(numobjs):
                    #suma = suma + adjs[j, k]*x[step, k, :]
                    # NOTE: WITH EDGE CONVOLUTION:
                    suma = suma + adjs[j, k]*self.ec1(torch.cat((x[step, j, :], x[step, k, :])))
                _, out = self.gru(suma.view([1,1,-1]), hidden_states[j].view([1,1,-1]))
                new_hidden_states.append(out[0, 0])
            hidden_states = new_hidden_states
                #hidden_states[j] = out[0,0]

        return torch.stack(hidden_states), adjs
        #return torch.stack(hidden_states), torch.stack(all_adjs)


class graph_model_edgeconv_softmax(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(graph_model_edgeconv_softmax, self).__init__()
        self.secondtime = secondtime
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        print("REMEMBER WE\'RE USING A SLIGHTLY MODIFIED VERSION OF THE GRAPH MODEL!! ONLY ONE GRAPH LAYER DIRECTLY TO nout")
        #self.gc1 = GraphConvolution(nfeat, nout, bias=use_bias)
        #self.gc1 = nn.Linear(nfeat*2, nout, bias=use_bias)
        self.ec1 = nn.Linear(nfeat*2, nhid, bias=use_bias)
        self.ec2 = nn.Linear(nhid*2, nout, bias=use_bias)
        self.dropout = dropout

        #self.conv_gc1 = nn.Conv2d(nfeat*2, nfeat, 1, bias=False)
        #self.conv_gc2 = nn.Conv2d(nfeat, 1, 1, bias=False)
        self.conv_gc1 = nn.Conv2d(nfeat*2, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=False):
        max_size = np.max(sizes)
        #adjs = torch.zeros([len(x), self.nfeat, max_size, max_size])
        adjs = torch.zeros([len(x), self.nfeat*2, max_size, max_size])
        adjs = adjs.cuda()
        adjs = Variable(adjs)
        for i in range(len(x)):
            for j in range(sizes[i]):
                for k in range(sizes[i]):
                    adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])

        # NOTE USING 2 in order to model nonlinear funcions
        #adjs = F.relu(self.conv_gc1(adjs))
        #adjs = self.conv_gc2(adjs)
        adjs = self.conv_gc1(adjs)
        adjs = nn.Softmax(-1)(adjs).squeeze(1)

        k = 2 # Could do depending on sizes
        out_rep1 = []
        for i in range(len(x)):
            rep = []
            for j in range(sizes[i]):
                feats = []
                for k in range(sizes[i]):
                    #adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])
                    feats.append(torch.cat([x[i][j], x[i][j] - x[i][k]]))
                feats = torch.stack(feats)
                feats = self.ec1(feats)
                feats = torch.matmul(adjs[i, j], feats)
                # Otherwise, trivial way is to reshape adj and repeat value in second dimension, multiply it by feats and mean(0) or sum(0)
                rep.append(feats)
            out_rep1.append(torch.stack(rep))
        out_rep1 = torch.stack(out_rep1)

        return out_rep1, adjs


class graph_model_edgeconv_normalizeadj(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(graph_model_edgeconv_normalizeadj, self).__init__()
        self.secondtime = secondtime
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        print("REMEMBER WE\'RE USING A SLIGHTLY MODIFIED VERSION OF THE GRAPH MODEL!! ONLY ONE GRAPH LAYER DIRECTLY TO nout")
        #self.gc1 = GraphConvolution(nfeat, nout, bias=use_bias)
        #self.gc1 = nn.Linear(nfeat*2, nout, bias=use_bias)
        self.ec1 = nn.Linear(nfeat*2, nhid, bias=use_bias)
        self.ec2 = nn.Linear(nhid*2, nout, bias=use_bias)
        self.dropout = dropout

        self.sig = nn.Sigmoid()
        self.conv_gc1 = nn.Conv2d(nfeat*2, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=False):
        max_size = np.max(sizes)
        #adjs = torch.zeros([len(x), self.nfeat, max_size, max_size])
        adjs = torch.zeros([len(x), self.nfeat*2, max_size, max_size])
        adjs = adjs.cuda()
        adjs = Variable(adjs)
        for i in range(len(x)):
            for j in range(sizes[i]):
                for k in range(sizes[i]):
                    adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])

        #adjs = self.conv_gc1(adjs)
        #adjs = nn.Softmax(-1)(adjs).squeeze(1)

        eps = torch.FloatTensor([1e-5])
        eps = eps.cuda()
        adjs = self.conv_gc1(adjs)
        adjs = self.sig(adjs) + eps
        adjs = adjs.view([len(x), max_size, max_size])

        # Normalize:
        norms = adjs.norm(p=1, dim=(2), keepdim=True)
        adjs = adjs/norms.repeat(1, 1, max_size)

        out_rep1 = []
        for i in range(len(x)):
            rep = []
            for j in range(sizes[i]):
                feats = []
                for k in range(sizes[i]):
                    #adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])
                    feats.append(torch.cat([x[i][j], x[i][j] - x[i][k]]))
                feats = torch.stack(feats)
                feats = self.ec1(feats)
                feats = torch.matmul(adjs[i, j], feats)
                # Otherwise, trivial way is to reshape adj and repeat value in second dimension, multiply it by feats and mean(0) or sum(0)
                rep.append(feats)
            out_rep1.append(torch.stack(rep))
        out_rep1 = torch.stack(out_rep1)

        return out_rep1, adjs


class graph_model_1edgeconv(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(graph_model_1edgeconv, self).__init__()
        self.ec1 = nn.Linear(nfeat*2, nout, bias=use_bias)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=False):
        max_size = np.max(sizes)
        #adjs = torch.zeros([len(x), self.nfeat, max_size, max_size])
        adjs = torch.zeros([len(x), self.nfeat*2, max_size, max_size])
        adjs = adjs.cuda()
        adjs = Variable(adjs)
        out_rep = []
        for i in range(len(x)):
            rep = []
            for j in range(sizes[i]):
                feats = []
                for k in range(sizes[i]):
                    #adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])
                    feats.append(torch.cat([x[i][j], x[i][j] - x[i][k]]))
                feats = torch.stack(feats)
                rep.append(self.ec1(feats).sum(0))
            out_rep.append(torch.stack(rep))
        out_rep = torch.stack(out_rep)

        adjs = None
        if get_adj:
            dist = pairwise_distance(out_rep)
            edges = knn(dist, k=2)

            # Convert edges into an adjacency matrix!
            adjs = torch.zeros([len(x), x.shape[1], x.shape[1]])
            for i in range(len(edges)):
                for j in range(len(edges[i])):
                    adjs[i][edges[i][j][0], edges[i][j][1]] = 1.0
                    adjs[i][edges[i][j][1], edges[i][j][0]] = 1.0

        return out_rep, adjs


class graph_model_2edgeconv(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(graph_model_2edgeconv, self).__init__()
        self.ec1 = nn.Linear(nfeat*2, nhid, bias=use_bias)
        self.ec2 = nn.Linear(nhid*2, nout, bias=use_bias)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=False):
        k = 2 # Could do depending on sizes
        out_rep1 = []
        for i in range(len(x)):
            rep = []
            for j in range(sizes[i]):
                feats = []
                for k in range(sizes[i]):
                    #adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])
                    feats.append(torch.cat([x[i][j], x[i][j] - x[i][k]]))
                feats = torch.stack(feats)
                rep.append(self.ec1(feats).sum(0))
            out_rep1.append(torch.stack(rep))
        out_rep1 = torch.stack(out_rep1)
        out_rep1 = F.relu(out_rep1)

        dist = pairwise_distance(out_rep1)
        edges = knn(dist, k=k)

        out_rep2 = []
        for i in range(len(out_rep1)):
            rep = []
            for j in range(sizes[i]):
                feats = []
                # Own interaction:
                feats.append(torch.cat([out_rep1[i][j], out_rep1[i][j] - out_rep1[i][j]]))
                # Interaction with rest of nodes:
                for k in range(1, k):
                    val = edges[i][j][k]
                    feats.append(torch.cat([out_rep1[i][j], out_rep1[i][j] - out_rep1[i][val]]))
                feats = torch.stack(feats)
                rep.append(self.ec1(feats).sum(0))
            out_rep2.append(torch.stack(rep))
        out_rep2 = torch.stack(out_rep2)

        adjs = None
        if get_adj:
            dist = pairwise_distance(out_rep2)
            edges = knn(dist, k=2)

            # Convert edges into an adjacency matrix!
            adjs = torch.zeros([len(x), x.shape[1], x.shape[1]])
            for i in range(len(edges)):
                for j in range(len(edges[i])):
                    adjs[i][edges[i][j][0], edges[i][j][1]] = 1.0
                    adjs[i][edges[i][j][1], edges[i][j][0]] = 1.0

        return out_rep2, adjs


def pairwise_distance(point_cloud):
    """
    Args:
    point_cloud: tensor (batch_size, num_points, num_dims)
    Returns:
    pairwise distance: (batch_size, num_points, num_points)
    """
    batch_size = point_cloud.size()[0]
    point_cloud = torch.squeeze(point_cloud)
    if batch_size==1:
        point_cloud = point_cloud.unsqueeze(0)
    point_cloud_transpose = point_cloud.permute(0, 2, 1)
    point_cloud_inner = -2*torch.bmm(point_cloud, point_cloud_transpose)
    point_cloud_square = (point_cloud**2).sum(dim=-1, keepdim=True)
    point_cloud_square_transpose = point_cloud_square.permute(0, 2, 1)
    return point_cloud_square + point_cloud_inner + point_cloud_square_transpose


def knn(dist_mat, k=20):
    """
    Args:
    pairwise distance: (batch_size, num_points, num_points)
    k: int
    Returns:
    nearest neighbors: (batch_size, num_points, k)
    """
    _, nn_idx = torch.topk(dist_mat, k=k, largest=False, sorted=False)
    return nn_idx


class graph_model_gpnnconv_softmax(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(graph_model_gpnnconv_softmax, self).__init__()
        self.secondtime = secondtime
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        print("REMEMBER WE\'RE USING A SLIGHTLY MODIFIED VERSION OF THE GRAPH MODEL!! ONLY ONE GRAPH LAYER DIRECTLY TO nout")
#        self.gc1 = GraphConvolution(nfeat, nout, bias=use_bias)
        self.gc1 = GraphConvolution(nfeat, nhid, bias=use_bias)
        self.gc2 = GraphConvolution(nhid, nout, bias=use_bias)
        #self.gc2 = GraphConvolution(nfeat, nout)
        self.dropout = dropout
        # NOTE: K-nn?
        self.sig = nn.Sigmoid()
        #self.conv_gc1 = nn.Conv2d(nfeat, 1, 1)
        self.conv_gc1 = nn.Conv2d(nfeat*2, 1, 1, bias=False)
#        self.conv_gc2 = nn.Conv2d(nhid*2, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=True):
        # Build matrix 
        max_size = np.max(sizes)
        #adjs = torch.zeros([len(x), self.nfeat, max_size, max_size])
        adjs = torch.zeros([len(x), self.nfeat*2, max_size, max_size])
        adjs = adjs.cuda()
        adjs = Variable(adjs)
        for i in range(len(x)):
            for j in range(sizes[i]):
                for k in range(sizes[i]):
                    adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])

        adjs = self.conv_gc1(adjs)
        adjs = nn.Softmax(-1)(adjs).squeeze(1)
        #adjs = adjs.view([1, max_size, max_size])

        #eps = torch.FloatTensor([1e-5])
        #eps = eps.cuda()
        #norms = x.norm(p=1, dim=(2), keepdim=True)
        #normed_xs = x/norms.repeat(1, 1, 6)
        for i in range(len(x)):
            x[i] = normalize_tensor(x[i])

        x = F.relu(self.gc1(x, adjs))

        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adjs)

        return x, adjs


def normalize_tensor(mx):
    """Row-normalize sparse matrix"""

    rowsum = mx.sum(1)
    r_inv = 1/rowsum.flatten()
    r_inv[r_inv == float("Inf")] = 0
    r_mat_inv = torch.diag(r_inv)
    mx = torch.mm(r_mat_inv, mx)
    return mx


class graph_model_gpnnconv_softmax_shorter(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(graph_model_gpnnconv_softmax_shorter, self).__init__()
        self.secondtime = secondtime
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        self.gc1 = GraphConvolution(nfeat, nhid, bias=use_bias)
        self.gc2 = GraphConvolution(nhid, nout, bias=use_bias)
        #self.gc2 = GraphConvolution(nfeat, nout)
        self.dropout = dropout
        # NOTE: K-nn?
        self.sig = nn.Sigmoid()
        #self.conv_gc1 = nn.Conv2d(nfeat, 1, 1)
        self.conv_gc1 = nn.Conv2d(85*2, 1, 1, bias=False)
        #self.conv_gc1 = nn.Conv2d(nfeat*2, 1, 1, bias=False)
        self.conv_gc2 = nn.Conv2d(nhid*2, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid

    def forward(self, x, sizes, get_adj=True):
        # Build matrix 
        max_size = np.max(sizes)
        adjs = torch.zeros([len(x), 85*2, max_size, max_size])
        #adjs = torch.zeros([len(x), self.nfeat*2, max_size, max_size])
        adjs = adjs.cuda()
        adjs = Variable(adjs)
        for i in range(len(x)):
            for j in range(sizes[i]):
                for k in range(sizes[i]):
#                    adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])
                    adjs[i, :160, j, k] = torch.cat([x[i][j][:80], x[i][k][:80]])
                    adjs[i, 160:, j, k] = torch.cat([x[i][j][445:450], x[i][j][445:450] - x[i][k][445:450]])


        adjs = self.conv_gc1(adjs)
        adjs = nn.Softmax(-1)(adjs)
        adjs = adjs.view([1, max_size, max_size])

        x = F.relu(self.gc1(x, adjs))

        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adjs)

        return x, adjs



class graph_model_gpnnconv(NetworkBase):
    def __init__(self, nfeat, nhid, nout, dropout=0.5, secondtime=False, use_bias=True):
        super(graph_model_gpnnconv, self).__init__()
        self.secondtime = secondtime
        # NOTE: Assuming graph is given first, for instance through a fully connected graph initially?
        self.gc1 = GraphConvolution(nfeat, nhid, bias=use_bias)
        self.gc2 = GraphConvolution(nhid, nout, bias=use_bias)
        #self.gc2 = GraphConvolution(nfeat, nout)
        self.dropout = dropout
        # NOTE: K-nn?
        self.sig = nn.Sigmoid()
        #self.conv_gc1 = nn.Conv2d(nfeat, 1, 1)
        self.conv_gc1 = nn.Conv2d(nfeat*2, 1, 1, bias=False)
        self.conv_gc2 = nn.Conv2d(nhid*2, 1, 1, bias=False)
        self.nfeat = nfeat
        self.nhid = nhid
    
    def forward(self, x, sizes, get_adj=True):
        # Build matrix  
        max_size = np.max(sizes)
        adjs = torch.zeros([len(x), self.nfeat*2, max_size, max_size])
        adjs = adjs.cuda()
        adjs = Variable(adjs)
        for i in range(len(x)):
            for j in range(sizes[i]):
                for k in range(sizes[i]):
                    adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])

        eps = torch.FloatTensor([1e-5])
        eps = eps.cuda()

        adjs = self.conv_gc1(adjs)
        adjs = self.sig(adjs) + eps
        adjs = adjs.view([len(x), max_size, max_size])

        # Turn invented nodes' adjacency to zeros:
        eye = torch.eye(int(max_size))
        for i in range(len(x)):
            adjs[i][sizes[i]:, :] = eye[sizes[i]:, :]
            adjs[i][:, sizes[i]:] = eye[:, sizes[i]:]

        # Normalize:
        norms = adjs.norm(p=1, dim=(2), keepdim=True)
        normed_adjs = adjs/norms.repeat(1, 1, max_size)

        x = F.relu(self.gc1(x, normed_adjs))

        if self.secondtime:
            adjs1 = adjs
            # Build matrix 
            max_size = np.max(sizes)
            adjs = torch.zeros([len(x), self.nhid*2, max_size, max_size])
            adjs = adjs.cuda()
            adjs = Variable(adjs)
            for i in range(len(x)):
                for j in range(sizes[i]):
                    for k in range(sizes[i]):
                        adjs[i, :, j, k] = torch.cat([x[i][j], x[i][j]-x[i][k]])

            eps = torch.FloatTensor([1e-5])
            eps = eps.cuda()

            adjs = self.conv_gc2(adjs)
            adjs = self.sig(adjs) + eps
            adjs = adjs.view([len(x), max_size, max_size])

            # Turn invented nodes' adjacency to zeros:
            eye = torch.eye(int(max_size))
            for i in range(len(x)):
                adjs[i][sizes[i]:, :] = eye[sizes[i]:, :]
                adjs[i][:, sizes[i]:] = eye[:, sizes[i]:]

            # Normalize:
            norms = adjs.norm(p=1, dim=(2), keepdim=True)
            normed_adjs = adjs/norms.repeat(1, 1, max_size)

            x = F.dropout(x, self.dropout, training=self.training)
            x = self.gc2(x, normed_adjs)
            return x, [adjs1, adjs]


        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, normed_adjs)

        return x, adjs
