import os.path
import torchvision.transforms as transforms
from data.dataset import DatasetBase
from PIL import Image
import random
import numpy as np
import pickle
from utils import cv_utils
from sklearn.preprocessing import LabelEncoder
from torch._six import string_classes, int_classes, FileNotFoundError
import torch


class kitDataset(DatasetBase):
    def __init__(self, opt, mode, mean=None, std=None):
        # TODO: CORRECT THING THAT IS PERSON MAY BE WRONG!!

        super(kitDataset, self).__init__(opt, mode)

        #self.noise_cm_std = 0
        #self.noise_cm_std = 15
        self.noise_cm_std = 0 #28.867513459481287 # mm
        #self.noise_cm_std = 57.735026918962575 #28.867513459481287 # mm
        print("Noise std is " + str(self.noise_cm_std) + "!!!!")

        self._name = 'kitDataset'
        self.thres_prob_joints = opt.thres_prob_joints
        seq_length = self._opt.seq_length_in + self._opt.seq_length_out

        # read dataset
        self.data_dir = opt.data_dir

        # NOTE POUR-related actions
        self.files = np.load(self.data_dir + '/files_lean.npy',allow_pickle=True)
        self.joints = np.load(self.data_dir + '/joints_lean.npy',allow_pickle=True)
        self.bbxes = np.load(self.data_dir + '/bbxes_lean.npy',allow_pickle=True)
        self.isperson = np.load(self.data_dir + '/isobject_lean.npy',allow_pickle=True) # It should be called 'isperson' instead
        self.objects = np.load(self.data_dir + '/objects_lean.npy',allow_pickle=True)

        # CLASSES ARE:
        # Pour, cutting, lean on/over table, pick and place object, use table as a support for walking and others, mechanic assisted by another person
        movement_classes = [['pour'], ['cutting'], ['lean_'], ['cup', 'egg_whisk', 'knife', 'sponge'], ['walk', 'kneel', 'inspect_shoe_sole'], ['912_'], ['drink'], ['mixing', 'stirring'], ['wiping_the_table']]
        labels = np.zeros(len(self.files)) - 1
        for i in range(len(self.files)):
            for j in range(len(movement_classes)):
                for k in range(len(movement_classes[j])):
                    if movement_classes[j][k] in self.files[i]:
                        labels[i] = j

        self.video_class_labels = labels

#        allobjs = []
#        for i in range(len(self.objects)):
#            allobjs += self.objects[i]
#        uniqueobjs = np.unique(allobjs)

        self.objs = ['Human', 'Table', 'sponge_wet', 'Red_Cup', 'BigBox']

        # ONE-HOT ENCODING GT CLASSES
        label_encoder = LabelEncoder()
        label_encoder = label_encoder.fit(self.objs)

        for i in range(len(self.objects)):
            # Replace all human definitions by keyword Human:
            for j, n in enumerate(self.objects[i]):
                if 'subj' in n or n.isdigit():
                    self.objects[i][j] = 'Human'
            self.objects[i] = label_encoder.transform(self.objects[i])

        self.label_encoder_classes = label_encoder.classes_

        # TODO: NORMALIZE RESPECT SOME PARTICULAR JOINT ON THE BEGINNING OF SEQUENCE
        #joint_means = np.zeros((16, 3))
        xyzs = []
        samples = 0
        for i in range(len(self.joints)):
            xyzs += self.joints[i].reshape([-1, 3]).tolist()
            samples += len(self.joints[i])

        self.std_joints = np.std(xyzs)
        self.mean_joints = np.mean(xyzs)
        #self.std_joints = np.std(xyzs, 0)
        #self.mean_joints = np.mean(xyzs, 0)

        #for i in range(len(self.joints)):
        #    self.joints[i] /= self.std_joints
        #    self.bbxes[i] /= np.array((self.std_joints[0], self.std_joints[1], self.std_joints[2],
        #                            self.std_joints[0], self.std_joints[1], self.std_joints[2]))

        inds = np.arange(len(self.files))
        np.random.seed(1)
        np.random.shuffle(inds)

        nsamples = len(self.files)
        ntrain = int(nsamples*0.6)
        nvalid = int(nsamples*0.2)
        ntest = int(nsamples*0.2)
        # Load sequences
        if self._mode=='train':
            self.files = self.files[inds[:ntrain]]
            self.joints = self.joints[inds[:ntrain]]
            self.bbxes = self.bbxes[inds[:ntrain]]
            self.isperson = self.isperson[inds[:ntrain]]
            self.objects = self.objects[inds[:ntrain]]
        elif self._mode=='valid':
            self.files = self.files[inds[ntrain:ntrain+nvalid]]
            self.joints = self.joints[inds[ntrain:ntrain+nvalid]]
            self.bbxes = self.bbxes[inds[ntrain:ntrain+nvalid]]
            self.isperson = self.isperson[inds[ntrain:ntrain+nvalid]]
            self.objects = self.objects[inds[ntrain:ntrain+nvalid]]
        elif self._mode=='test':
            self.files = self.files[inds[ntrain+nvalid:]]
            self.joints = self.joints[inds[ntrain+nvalid:]]
            self.bbxes = self.bbxes[inds[ntrain+nvalid:]]
            self.isperson = self.isperson[inds[ntrain+nvalid:]]
            self.objects = self.objects[inds[ntrain+nvalid:]]

        cheatsheet_samples = np.array([])
        beginning_samples = np.array([])
        for i in range(len(self.joints)):
            cheatsheet_samples = np.concatenate((cheatsheet_samples, np.ones(max(0, len(self.joints[i]) - seq_length))*i))
            beginning_samples = np.concatenate((beginning_samples, np.arange(max(0, len(self.joints[i]) - seq_length))))
        self.cheatsheet_samples = cheatsheet_samples
        self.beginning_samples = beginning_samples

    def __getitem__(self, index):
        assert (index < len(self.cheatsheet_samples))

        ind = int(self.cheatsheet_samples[index])
        beginning = int(self.beginning_samples[index])

        video_class_label = self.video_class_labels[ind]

        encoder_inputs = self.joints[ind][beginning:beginning + self.seq_length_in:self.seq_step].copy()
        #decoder_inputs = self.joints[ind][beginning + self.seq_length_in - 1:beginning + self.seq_length_in + self.seq_length_out - 1:self.seq_step].copy()
        decoder_outputs = self.joints[ind][beginning + self.seq_length_in:beginning + self.seq_length_in + self.seq_length_out:self.seq_step].copy()

        img_name = self.files[ind]
        affected_nodes = self.isperson[ind]

        feats = self.bbxes[ind][beginning:beginning +self.seq_length_in:self.seq_step].copy()
        objs = self.objects[ind]

        # Add object class as a one hot vector
        length = len(feats)
        size = len(objs)
        onehot_class = np.zeros((length, size, len(self.objs)))
        onehot_class[:, np.arange(size), np.int32(objs)] = 1
        feats = np.concatenate((feats, onehot_class), 2)

        # Get future features
        future_feats = self.bbxes[ind][beginning + self.seq_length_in:beginning + self.seq_length_in + self.seq_length_out:self.seq_step].copy()
        length = len(future_feats)
        size = len(objs)
        onehot_class = np.zeros((length, size, len(self.objs)))
        onehot_class[:, np.arange(size), np.int32(objs)] = 1
        future_feats = np.concatenate((future_feats, onehot_class), 2)

        # Normalizing things a bit
        encoder_inputs -= self.mean_joints
        #decoder_inputs -= self.mean_joints
        decoder_outputs -= self.mean_joints
        encoder_inputs /= self.std_joints
        #decoder_inputs /= self.std_joints
        decoder_outputs /= self.std_joints

        feats[:, :, :6] -= self.mean_joints
        feats[:, :, :6] /= self.std_joints

        future_feats[:, :, :6] -= self.mean_joints
        future_feats[:, :, :6] /= self.std_joints

        if self._mode == 'train':
            # Augmentation. Rotate randomly all the scene on Z-axis
            angle = np.random.uniform(0, 2*np.pi)
            rotm = [[np.cos(angle), -1*np.sin(angle), 0], [np.sin(angle), np.cos(angle), 0], [0, 0, 1]]

            encoder_inputs = np.matmul(encoder_inputs, rotm)
            #decoder_inputs = np.matmul(decoder_inputs, rotm)
            decoder_outputs = np.matmul(decoder_outputs, rotm)

            # 8 points bounding box:
            verts = [[feats[:, :, 0], feats[:, :, 1], feats[:, :, 2]],
                    [feats[:, :, 3], feats[:, :, 1], feats[:, :, 2]],
                    [feats[:, :, 0], feats[:, :, 4], feats[:, :, 2]],
                    [feats[:, :, 0], feats[:, :, 1], feats[:, :, 5]],
                    [feats[:, :, 3], feats[:, :, 4], feats[:, :, 2]],
                    [feats[:, :, 3], feats[:, :, 1], feats[:, :, 5]],
                    [feats[:, :, 0], feats[:, :, 4], feats[:, :, 5]],
                    [feats[:, :, 3], feats[:, :, 4], feats[:, :, 5]]]

            verts = np.transpose(verts, (2, 3, 0, 1))
            verts = np.matmul(verts, rotm)
            minverts = np.min(verts, 2)
            maxverts = np.max(verts, 2)
            feats[:, :, :3] = minverts
            feats[:, :, 3:6] = maxverts

            # 8 points bounding box:
            verts = [[future_feats[:, :, 0], future_feats[:, :, 1], future_feats[:, :, 2]],
                    [future_feats[:, :, 3], future_feats[:, :, 1], future_feats[:, :, 2]],
                    [future_feats[:, :, 0], future_feats[:, :, 4], future_feats[:, :, 2]],
                    [future_feats[:, :, 0], future_feats[:, :, 1], future_feats[:, :, 5]],
                    [future_feats[:, :, 3], future_feats[:, :, 4], future_feats[:, :, 2]],
                    [future_feats[:, :, 3], future_feats[:, :, 1], future_feats[:, :, 5]],
                    [future_feats[:, :, 0], future_feats[:, :, 4], future_feats[:, :, 5]],
                    [future_feats[:, :, 3], future_feats[:, :, 4], future_feats[:, :, 5]]]

            verts = np.transpose(verts, (2, 3, 0, 1))
            verts = np.matmul(verts, rotm)
            minverts = np.min(verts, 2)
            maxverts = np.max(verts, 2)
            future_feats[:, :, :3] = minverts
            future_feats[:, :, 3:6] = maxverts

            # Augmentation. Translate all the scene in axes XY between -2 and 2?
            translation = np.random.uniform(-1, 1, 2)
            encoder_inputs[:, :, 0] = encoder_inputs[:, :, 0] + translation[0]
            encoder_inputs[:, :, 1] = encoder_inputs[:, :, 1] + translation[1]

            #decoder_inputs[:, :, 0] = decoder_inputs[:, :, 0] + translation[0]
            #decoder_inputs[:, :, 1] = decoder_inputs[:, :, 1] + translation[1]

            decoder_outputs[:, :, 0] = decoder_outputs[:, :, 0] + translation[0]
            decoder_outputs[:, :, 1] = decoder_outputs[:, :, 1] + translation[1]

            feats[:,:,0] = feats[:,:,0] + translation[0]
            feats[:,:,1] = feats[:,:,1] + translation[1]
            feats[:,:,3] = feats[:,:,3] + translation[0]
            feats[:,:,4] = feats[:,:,4] + translation[1]
            future_feats[:,:,0] = future_feats[:,:,0] + translation[0]
            future_feats[:,:,1] = future_feats[:,:,1] + translation[1]
            future_feats[:,:,3] = future_feats[:,:,3] + translation[0]
            future_feats[:,:,4] = future_feats[:,:,4] + translation[1]

        # Add joints in features (past ans future):
        idx = np.argwhere(affected_nodes == 1)[0]
        complete_feats = np.concatenate((feats, np.zeros((len(feats), len(feats[0]), 18*3))), 2)
        complete_feats[:, idx, -18*3:] = encoder_inputs.reshape((-1, 1, 18*3))
        feats = complete_feats

        complete_future_feats = np.concatenate((future_feats, np.zeros((len(future_feats), len(future_feats[0]), 18*3))), 2)
        complete_future_feats[:, idx, -18*3:] = decoder_outputs.reshape((-1, 1, 18*3))
        future_feats = complete_future_feats

        # Augment data adding noise in joints
        if self.noise_cm_std > 0:
            print("Remember we're adding noise in the encoder+feature inputs drawing from a Gaussian distribution with " + str(self.noise_cm_std) + "std [cm]")
            noise_joints = np.random.normal(0, self.noise_cm_std, (10, 1, 18*3)) / self.std_joints
            noise_feats = np.random.normal(0, self.noise_cm_std, (10, len(objs), 6)) / self.std_joints

            feats[:, :, :6] = feats[:, :, :6] + noise_feats
            encoder_inputs = encoder_inputs + noise_joints.reshape((10, 18, 3))
            feats[:, idx, -1*18*3:] = feats[:, idx, -1*18*3:] + noise_joints


        sample = {'encoder_inputs': encoder_inputs,
                  #'decoder_inputs': decoder_inputs,
                  'decoder_outputs': decoder_outputs,
                  'img_name': img_name,
                  'frame_beginning_sequence': beginning,
                  'affected_nodes': affected_nodes,
                  'features': feats,
                  'features_future': future_feats,
                  'objects': objs,
                  'feature_sizes': len(feats[0]),
                  'norm': self.std_joints,
                  'label_encoder_classes_': self.label_encoder_classes,
                  'video_class_label': video_class_label
                 }
        return sample

    # Function to join batchs on dataloader pytorch function. Needed to work on batches 
    # that contain data of different size.
    def collate_fn(self, args):
        length = len(args)
        keys = list(args[0].keys())
        data = {}

        for i, key in enumerate(keys):
            data_type = []

            if key == 'scene_class':
                for j in range(length):
                    val = args[j][key]
                    if np.isscalar(val):
                        val = [val]
                    data_type.append(torch.LongTensor(val))
                val = args[j][key]
                data_type = torch.stack(data_type)
            elif key == 'encoder_inputs' or key == 'decoder_inputs' or key == 'decoder_outputs' or key == 'probability_joints':
                for j in range(length):
                    data_type.append(torch.DoubleTensor(args[j][key]))
                data_type = torch.stack(data_type)
            else:
                for j in range(length):
                    data_type.append(args[j][key])
            data[key] = data_type

        return data

    def __len__(self):
        return len(self.cheatsheet_samples)
