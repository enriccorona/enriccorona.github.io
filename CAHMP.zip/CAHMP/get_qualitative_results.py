import time
import utils
from options.test_options import TestOptions
from data.custom_dataset_data_loader import CustomDatasetDataLoader
from models.models import ModelsFactory
from utils.tb_visualizer import TBVisualizer
from collections import OrderedDict
import os


class Test:
    def __init__(self):

        self._opt = TestOptions().parse()
        #assert self._opt.load_epoch > 0, 'Use command --load_epoch to indicate the epoch you want to load - and choose a trained model'

        data_loader_test = CustomDatasetDataLoader(self._opt, mode='test')
        self._dataset_test = data_loader_test.load_data()
        self._dataset_test_size = len(data_loader_test)
        print('#test images = %d' % self._dataset_test_size)

        self._model = ModelsFactory.get_by_name(self._opt.model, self._opt)
        self._tb_visualizer = TBVisualizer(self._opt)

        self._total_steps = self._dataset_test_size
        self._display_visualizer_test(20, self._total_steps)

    def _display_visualizer_test(self, i_epoch, total_steps):
        test_start_time = time.time()

        # set model to eval
        self._model.set_eval()

        # evaluate self._opt.num_iters_validate epochs
        test_errors = OrderedDict()
        statistics = OrderedDict()
        iters = 0
        for i_test_batch, test_batch in enumerate(self._dataset_test):
            # evaluate model
            self._model.set_input(test_batch)
            self._model.forward(keep_data_for_visuals=True, obtain_errors=True)
            errors = self._model.get_current_errors()

            # store current batch errors
            for k, v in errors.items():
                if k in test_errors:
                    test_errors[k] += v
                else:
                    test_errors[k] = v

            iters += 1
            if (iters % 10) == 0:
                print(str(iters) + '/' + str(len(self._dataset_test)))

            self._model.get_current_plotting_data(i_test_batch)

            ## NOTE DEBUGGING
        for k in test_errors.keys():
            test_errors[k] /= iters

        t = (time.time() - test_start_time)
        self._tb_visualizer.print_current_test_errors(i_epoch, test_errors, t)


if __name__ == "__main__":
    Test()
