from __future__ import print_function
import numpy as np
import socket
from utils import util

pc_name = socket.gethostname()
if pc_name == 'visen3':
    import matplotlib
    matplotlib.use('Agg')

import matplotlib.pyplot as plt
import skimage.io
import matplotlib.patches as patches
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection


def plot_only_movingobjects(past_features, predicted_movement, real_future_features):
    xmin = np.min(past_features[:, :, [0, 3]])
    xmax = np.max(past_features[:, :, [0, 3]])
    ymin = np.min(past_features[:, :, [1, 4]])
    ymax = np.max(past_features[:, :, [1, 4]])
    zmin = np.min(past_features[:, :, [2, 5]])
    zmax = np.max(past_features[:, :, [2, 5]])

    tmax = max((xmax, ymax, zmax))
    tmin = min((xmin, ymin, zmin))

    plots = []
    for i in range(len(past_features)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        for j in range(len(past_features[i])):
            if past_features[i][j][-18*3:].std() > 0.1:
                plot_skeleton_3d(ax, past_features[i][j][-18*3:].reshape([18, 3]), 'b')
            else:
                plot_bbxes(ax, past_features[i][np.newaxis, j], 'b', [0.3])
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    for i in range(len(real_future_features)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        for j in range(len(real_future_features[i])):
            if real_future_features[i][j][-18*3:].std() > 0.1:
                plot_skeleton_3d(ax, real_future_features[i][j][-18*3:].reshape([18, 3]), 'r')
            else:
                plot_bbxes(ax, real_future_features[i][np.newaxis, j], 'b', [0.0])
                plot_bbxes(ax, predicted_movement[i][np.newaxis, j], 'b', [0.0])
        # TODO: PLOT REAL FUTURE FEATURES TOO? OR TOO CROWDED
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    return np.array(plots)


def plot_3d_bayesian_allpredictions(past_features, future_features, real_future_features, adjs):
    xmin = np.min(past_features[:, :, [0, 3]])
    xmax = np.max(past_features[:, :, [0, 3]])
    ymin = np.min(past_features[:, :, [1, 4]])
    ymax = np.max(past_features[:, :, [1, 4]])
    zmin = np.min(past_features[:, :, [2, 5]])
    zmax = np.max(past_features[:, :, [2, 5]])

    tmax = max((xmax, ymax, zmax))
    tmin = min((xmin, ymin, zmin))

    plots = []
    for i in range(len(past_features)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        for j in range(len(past_features[i])):
            if past_features[i][j][-18*3:].std() > 0.1:
                plot_skeleton_3d(ax, past_features[i][j][-18*3:].reshape([18, 3]), 'b')
            else:
                plot_bbxes(ax, past_features[i][np.newaxis, j], 'b', [0.3])
        #plot_context_kit(ax, features[i], adjs[i])
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    for i in range(len(future_features)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        for k in range(len(future_features[i])):
            for j in range(len(future_features[i][k])):
                if future_features[i][k][j][-18*3:].std() > 0.1:
                    plot_skeleton_3d(ax, future_features[i][k][j][-18*3:].reshape([18, 3]), 'r')
                else:
                    plot_bbxes(ax, future_features[i][k][np.newaxis, j], 'r', [0.0])
        # TODO: PLOT REAL FUTURE FEATURES TOO? OR TOO CROWDED
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    return np.array(plots)


def plot_3d_allpredictions(past_features, future_features, real_future_features, adjs):
    xmin = np.min(past_features[:, :, [0, 3]])
    xmax = np.max(past_features[:, :, [0, 3]])
    ymin = np.min(past_features[:, :, [1, 4]])
    ymax = np.max(past_features[:, :, [1, 4]])
    zmin = np.min(past_features[:, :, [2, 5]])
    zmax = np.max(past_features[:, :, [2, 5]])

    tmax = max((xmax, ymax, zmax))
    tmin = min((xmin, ymin, zmin))

    plots = []
    for i in range(len(past_features)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        for j in range(len(past_features[i])):
            if past_features[i][j][-18*3:].std() > 0.1:
                plot_skeleton_3d(ax, past_features[i][j][-18*3:].reshape([18, 3]), 'b')
            else:
                plot_bbxes(ax, past_features[i][np.newaxis, j], 'b', [0.3])
        plot_context_kit(ax, past_features[i], adjs[i])
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    for i in range(len(future_features)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        for j in range(len(future_features[i])):
            if future_features[i][j][-18*3:].std() > 0.1:
                plot_skeleton_3d(ax, future_features[i][j][-18*3:].reshape([18, 3]), 'r')
                plot_skeleton_3d(ax, real_future_features[i][j][-18*3:].reshape([18, 3]), 'b')
            else:
                plot_bbxes(ax, future_features[i][np.newaxis, j], 'r', [0.3])
                plot_bbxes(ax, real_future_features[i][np.newaxis, j], 'b', [0.3])
        if i + 1 < len(future_features):
            plot_context_kit(ax, future_features[i], adjs[len(past_features) + i])
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    return np.array(plots)


def plot_3d_interactions_multiple_people(past, real, fake, features, idx, adjs):
    past = past.reshape([-1, 18, 3])
    if real is not None:
        real = real.reshape([-1, 18, 3])
    if fake is not None:
        fake = fake.reshape([-1, 18, 3])

    #xmin = min((past[:,:,0].min(), real[:,:,0].min(), fake[:,:,0].min()))
    #xmax = max((past[:,:,0].max(), real[:,:,0].max(), fake[:,:,0].max()))
    #ymin = min((past[:,:,1].min(), real[:,:,1].min(), fake[:,:,1].min()))
    #ymax = max((past[:,:,1].max(), real[:,:,1].max(), fake[:,:,1].max()))
    #zmin = min((past[:,:,2].min(), real[:,:,2].min(), fake[:,:,2].min()))
    #zmax = max((past[:,:,2].max(), real[:,:,2].max(), fake[:,:,2].max()))

    xmin = np.min(features[:, :, [0, 3]])
    xmax = np.max(features[:, :, [0, 3]])
    ymin = np.min(features[:, :, [1, 4]])
    ymax = np.max(features[:, :, [1, 4]])
    zmin = np.min(features[:, :, [2, 5]])
    zmax = np.max(features[:, :, [2, 5]])

    tmax = max((xmax, ymax, zmax))
    tmin = min((xmin, ymin, zmin))

    plots = []
    alphas = [0.3]*len(features[0])
    #alphas[idx[0]] = 0.05
    objects = np.arange(len(features[0]))
    objects = np.delete(objects, idx[0])
    for i in range(len(past)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        #plot_skeleton_3d(ax, past[i], 'b')
        for j in range(len(features[i])):
            if features[i][j][-18*3:].std() > 0.1:
                plot_skeleton_3d(ax, features[i][j][-18*3:].reshape([18, 3]), 'b')
            else:
                plot_bbxes(ax, features[i][np.newaxis, j], 'c', alphas)
        plot_context_kit(ax, features[i], adjs[i])
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    for i in range(len(fake)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        if real is not None:
            plot_skeleton_3d(ax, real[i], 'b')
        if fake is not None:
            plot_skeleton_3d(ax, fake[i], 'r')
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    return np.array(plots)


def plot_3d_interactions(past, real, fake, features, idx, adjs):
    past = past.reshape([-1, 18, 3])
    if real is not None:
        real = real.reshape([-1, 18, 3])
    if fake is not None:
        fake = fake.reshape([-1, 18, 3])

#    xmin = min((past[:,:,0].min(), real[:,:,0].min(), fake[:,:,0].min()))
#    xmax = max((past[:,:,0].max(), real[:,:,0].max(), fake[:,:,0].max()))
#    ymin = min((past[:,:,1].min(), real[:,:,1].min(), fake[:,:,1].min()))
#    ymax = max((past[:,:,1].max(), real[:,:,1].max(), fake[:,:,1].max()))
#    zmin = min((past[:,:,2].min(), real[:,:,2].min(), fake[:,:,2].min()))
#    zmax = max((past[:,:,2].max(), real[:,:,2].max(), fake[:,:,2].max()))

    xmin = np.min(features[:, :, [0, 3]])
    xmax = np.max(features[:, :, [0, 3]])
    ymin = np.min(features[:, :, [1, 4]])
    ymax = np.max(features[:, :, [1, 4]])
    zmin = np.min(features[:, :, [2, 5]])
    zmax = np.max(features[:, :, [2, 5]])

    tmax = max((xmax, ymax, zmax))
    tmin = min((xmin, ymin, zmin))

    plots = []
    alphas = [0.3]*len(features[0])
    #alphas[idx[0]] = 0.05
    objects = np.arange(len(features[0]))
    objects = np.delete(objects, idx[0])
    for i in range(len(past)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        plot_skeleton_3d(ax, past[i], 'b')
        plot_bbxes(ax, features[i][objects], 'c', alphas)
        plot_context_kit(ax, features[i], adjs[i])
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    for i in range(len(fake)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        if real is not None:
            plot_skeleton_3d(ax, real[i], 'b')
        if fake is not None:
            plot_skeleton_3d(ax, fake[i], 'r')
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    return np.array(plots)


def plot_3d_bayesian_interactions(past, real, fake, features, idx, adjs):
    xmin = np.min(features[:, :, [0, 3]])
    xmax = np.max(features[:, :, [0, 3]])
    ymin = np.min(features[:, :, [1, 4]])
    ymax = np.max(features[:, :, [1, 4]])
    zmin = np.min(features[:, :, [2, 5]])
    zmax = np.max(features[:, :, [2, 5]])

    tmax = max((xmax, ymax, zmax))
    tmin = min((xmin, ymin, zmin))

    plots = []
    alphas = [0.3]*len(features[0])
    #alphas[idx[0]] = 0.05
    objects = np.arange(len(features[0]))
    objects = np.delete(objects, idx[0])
    for i in range(len(past)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        plot_skeleton_3d(ax, past[i], 'b')
        plot_bbxes(ax, features[i][objects], 'c', alphas)
        #plot_context_kit(ax, features[i], adjs[i])
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    for i in range(len(real)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        plot_skeleton_3d(ax, real[i], 'b')
        for j in range(len(fake[i])):
            plot_skeleton_3d(ax, fake[i][j], 'r')
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    return np.array(plots)


def plot_3d_stuff(past, real, fake, features, idx):
    past = past.reshape([-1, 18, 3])
    real = real.reshape([-1, 18, 3])
    fake = fake.reshape([-1, 18, 3])

    xmin = min((past[:,:,0].min(), real[:,:,0].min(), fake[:,:,0].min()))
    xmax = max((past[:,:,0].max(), real[:,:,0].max(), fake[:,:,0].max()))
    ymin = min((past[:,:,1].min(), real[:,:,1].min(), fake[:,:,1].min()))
    ymax = max((past[:,:,1].max(), real[:,:,1].max(), fake[:,:,1].max()))
    zmin = min((past[:,:,2].min(), real[:,:,2].min(), fake[:,:,2].min()))
    zmax = max((past[:,:,2].max(), real[:,:,2].max(), fake[:,:,2].max()))

    tmax = max((xmax, ymax, zmax))
    tmin = min((xmin, ymin, zmin))

    plots = []
    alphas = [0.3]*len(features[0])
    alphas[idx[0]] = 0.05
    for i in range(len(past)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        plot_skeleton_3d(ax, past[i], 'b')
        plot_bbxes(ax, features[i], 'c', alphas)
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    for i in range(len(real)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        plot_skeleton_3d(ax, real[i], 'b')
        plot_skeleton_3d(ax, fake[i], 'r')
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    return np.array(plots)


def plot_3d_bayesian_stuff(past, real, fake, features, idx):
    #past = past.reshape([-1, 18, 3])
    #real = real.reshape([-1, 18, 3])
    #fake = fake.reshape([-1, 18, 3])

    xmin = min((past[:,:,0].min(), real[:,:,0].min(), fake[:, :,:,0].min()))
    xmax = max((past[:,:,0].max(), real[:,:,0].max(), fake[:, :,:,0].max()))
    ymin = min((past[:,:,1].min(), real[:,:,1].min(), fake[:, :,:,1].min()))
    ymax = max((past[:,:,1].max(), real[:,:,1].max(), fake[:, :,:,1].max()))
    zmin = min((past[:,:,2].min(), real[:,:,2].min(), fake[:, :,:,2].min()))
    zmax = max((past[:,:,2].max(), real[:,:,2].max(), fake[:, :,:,2].max()))

    tmax = max((xmax, ymax, zmax))
    tmin = min((xmin, ymin, zmin))

    plots = []
    alphas = [0.3]*len(features[0])
    alphas[idx[0]] = 0.05
    for i in range(len(past)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        plot_skeleton_3d(ax, past[i], 'b')
        plot_bbxes(ax, features[i], 'c', alphas)
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    for i in range(len(real)):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_zlim(zmax, zmin)

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        plot_skeleton_3d(ax, real[i], 'b')
        for j in range(len(fake[i])):
            plot_skeleton_3d(ax, fake[i][j], 'r')
        ax.invert_zaxis()

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    return np.array(plots)


def plot_seq_3d(past, real, fake):
    past = past.reshape([-1, 18, 3])
    real = real.reshape([-1, 18, 3])
    fake = fake.reshape([-1, 18, 3])

    xmin = min((past[:,:,0].min(), real[:,:,0].min(), fake[:,:,0].min()))
    xmax = max((past[:,:,0].max(), real[:,:,0].max(), fake[:,:,0].max()))
    ymin = min((past[:,:,1].min(), real[:,:,1].min(), fake[:,:,1].min()))
    ymax = max((past[:,:,1].max(), real[:,:,1].max(), fake[:,:,1].max()))
    zmin = min((past[:,:,2].min(), real[:,:,2].min(), fake[:,:,2].min()))
    zmax = max((past[:,:,2].max(), real[:,:,2].max(), fake[:,:,2].max()))

    tmax = max((xmax, ymax, zmin))
    tmin = min((xmin, ymin, zmax))

    plots = []
    for i in range(len(past)):
        fig = plt.figure()
        plt.gca().invert_yaxis()
        ax = fig.add_subplot(111, projection='3d')
        #ax.axis('off')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(tmin, tmax)
        ax.set_ylim(tmax, tmin) # Invert since axis is inverted for images and skeletons
        ax.set_zlim(tmax, tmin) # Invert since axis is inverted for images and skeletons

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        plot_skeleton_3d(ax, past[i], 'b')

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    for i in range(len(real)):
        fig = plt.figure()
        plt.gca().invert_yaxis()
        ax = fig.add_subplot(111, projection='3d')
        #ax.axis('off')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(tmin, tmax)
        ax.set_ylim(tmax, tmin) # Invert since axis is inverted for images and skeletons

        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')

        plot_skeleton_3d(ax, real[i], 'b')
        plot_skeleton_3d(ax, fake[i], 'r')

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    return np.array(plots)


def plot_seq(past, real, fake, title=None, visualize=None):
    # Normalize skeleton to have -margin- pix width
#    margin = 100
#    num_sequences = len(sequence)

    past = past.reshape([-1, 17, 2])
    real = real.reshape([-1, 17, 2])
    fake = fake.reshape([-1, 17, 2])

    xmin = min((past[:,:,0].min(), real[:,:,0].min(), fake[:,:,0].min()))
    xmax = max((past[:,:,0].max(), real[:,:,0].max(), fake[:,:,0].max()))
    ymin = min((past[:,:,1].min(), real[:,:,1].min(), fake[:,:,1].min()))
    ymax = max((past[:,:,1].max(), real[:,:,1].max(), fake[:,:,1].max()))

    tmax = max((xmax, ymax))
    tmin = min((xmin, ymin))

    plots = []
    for i in range(len(past)):
        fig = plt.figure()
        plt.gca().invert_yaxis()
        ax = fig.add_subplot(1, 1, 1)
        ax.axis('off')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(tmin, tmax)
        ax.set_ylim(tmax, tmin) # Invert since axis is inverted for images and skeletons

        plot_skeleton(ax, past[i], 'b', visualize[i])

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    for i in range(len(real)):
        fig = plt.figure()
        ax = fig.add_subplot(1, 1, 1)
        ax.axis('off')
        fig.subplots_adjust(0.02, 0, 0.996, 1)  # get rid of margins
        ax.set_xlim(tmin, tmax)
        ax.set_ylim(tmax, tmin) # Invert since axis is inverted for images and skeletons

        plot_skeleton(ax, real[i], 'b', visualize[15+i])
        plot_skeleton(ax, fake[i], 'r', visualize[15+i])

        fig.canvas.draw()
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close(fig)
        plots.append(data)

    return np.array(plots)

def plot_skeleton_inimage(impath, pose_gt, pose_pred, visualize=None):
    # Normalize skeleton to have -margin- pix width
    img = skimage.io.imread(impath)

    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    ax.axis('off')
    fig.subplots_adjust(0.0, 0, 0.996, 1)  # get rid of margins

    ax.imshow(img)

    plot_skeleton(ax, pose_gt.reshape([17, 2]), 'b', visualize)
    plot_skeleton(ax, pose_pred.reshape([17, 2]), 'r', visualize)

    fig.canvas.draw()
    data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
    data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
    plt.close(fig)

    return data

def plot_skeleton(ax, pose, c, visualize=None):
    # 17 joints, with these connections:
    colors = ['r', 'r', 'r', 'r', 'r', 'y', 'y', 'y', 'y', 'y', 'y', 'g', 'g', 'g','g','g','g']
    pairs = [[0,1],[0,2],[1,3],[2,4],[5,6],[5,7],[7,9],[6,8],[8,10],[11,12],[11,13],[13,15],[12,14],[14,16],[6,12],[5,11]]

    if visualize is None:
        visualize = np.ones(len(pose))

    for idx_c, color in enumerate(colors):
        if visualize[idx_c]:
            plt.plot(pose[idx_c,0], pose[idx_c,1], marker='o', color=color)
    for idx in range(len(pairs)):
        if visualize[pairs[idx][0]] and visualize[pairs[idx][1]]:
            plt.plot(pose[pairs[idx], 0],pose[pairs[idx],1],'r-', color=c)

    return

def plot_skeleton_3d(ax, pose, c):
    # 17 joints, with these connections:
#    part_names = ['LFHD', 'RFHD', # HEAD
#                     'C7', 'T10', # TORSO
#                     'RSHO', 'LSHO', 'RAOL', 'LAOL', 'RWTS', 'LWTS', # ARMS
#                     'RHIP', 'LHIP', 'RKNE', 'LKNE', 'RMT5', 'LMT5' # LEGS
#                 ]
    people_joints = ['BHD', 'FHD', # HEAD
                     'C7', 'T10', # TORSO
                     'RSHO', 'LSHO', 'RAOL', 'LAOL', 'RWTS', 'LWTS', # ARMS
                     'RHIP', 'LHIP', 'RKNE', 'LKNE', 'RHEE', 'LHEE', 'RTOE', 'LTOE' # LEGS
                    ]

    colors = ['r', 'r', 'r', 'r', 'y', 'y', 'y', 'y', 'y', 'y', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g']
    #colors = ['r', 'r', 'r', 'r', 'y', 'y', 'g', 'g', 'y', 'y', 'y', 'y', 'g', 'g', 'g', 'g']
    pairs = [[0, 1], [0, 2], [2, 3], [2, 4], [2, 5], [3, 10], [3, 11], [4, 6], [5, 7], [6, 8], [7, 9], [10, 12], [11, 13], [12, 14], [13, 15], [14, 16], [15, 17]]

    for idx_c, color in enumerate(colors):
        ax.plot3D([pose[idx_c,0]], [pose[idx_c,1]], [pose[idx_c, 2]], marker='o', color=color)
    for idx in range(len(pairs)):
        ax.plot3D(pose[pairs[idx], 0],pose[pairs[idx],1], pose[pairs[idx], 2],'r-', color=c)

    return

def plot_bbxes(ax, features, c='cyan', alphas=[0.25]):
    for j in range(len(features)):
        verts = [[features[j][0], features[j][1], features[j][2]], 
                [features[j][3], features[j][1], features[j][2]],
                [features[j][0], features[j][4], features[j][2]],
                [features[j][0], features[j][1], features[j][5]],
                [features[j][3], features[j][4], features[j][2]],
                [features[j][3], features[j][1], features[j][5]],
                [features[j][0], features[j][4], features[j][5]],
                [features[j][3], features[j][4], features[j][5]]]
        cube_sides = [[verts[1], verts[0], verts[2], verts[4]],
                      [verts[1], verts[0], verts[3], verts[5]],
                      [verts[2], verts[0], verts[3], verts[6]],
                      [verts[4], verts[2], verts[6], verts[7]],
                      [verts[5], verts[3], verts[6], verts[7]],
                      [verts[4], verts[1], verts[5], verts[7]]]

        verts = np.array(verts)
        cube_sides = np.array(cube_sides)

        ax.scatter3D(verts[:, 0], verts[:, 1], verts[:, 2])
        collection = Poly3DCollection(cube_sides, 
            linewidths=1, edgecolors='r', alpha=alphas[j])
        collection.set_facecolor(c)
        ax.add_collection3d(collection)


def plot_context(imname, pose, features, adj, visualize=None):
    class_names = ['person', 'bicycle', 'car', 'motorcycle', 'airplane',
               'bus', 'train', 'truck', 'boat', 'traffic light',
               'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird',
               'cat', 'dog', 'horse', 'sheep', 'cow', 'elephant', 'bear',
               'zebra', 'giraffe', 'backpack', 'umbrella', 'handbag', 'tie',
               'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball',
               'kite', 'baseball bat', 'baseball glove', 'skateboard',
               'surfboard', 'tennis racket', 'bottle', 'wine glass', 'cup',
               'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple',
               'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza',
               'donut', 'cake', 'chair', 'couch', 'potted plant', 'bed',
               'dining table', 'toilet', 'tv', 'laptop', 'mouse', 'remote',
               'keyboard', 'cell phone', 'microwave', 'oven', 'toaster',
               'sink', 'refrigerator', 'book', 'clock', 'vase', 'scissors',
               'teddy bear', 'hair drier', 'toothbrush']

    img = skimage.io.imread(imname)

    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    ax.axis('off')
    fig.subplots_adjust(0.0, 0, 0.996, 1)  # get rid of margins

    ax.imshow(img)
    c = ['b', 'r', 'g', 'k', 'y', 'c', 'm', 'w']*1000

    for node_n in range(len(features)):
        plt.plot
        y, x, y2, x2 = features[node_n, 445:449]*1000
        if features[node_n, 0] > 0.99: # Should be 1 but there's numerical error
            pose = features[node_n, -34:]
            plot_skeleton(ax, pose.reshape([17, 2]), c[node_n])
        rect = patches.Rectangle((x,y),x2-x,y2-y,linewidth=2,edgecolor='k',facecolor='none')

        # Add the patch to the Axes
        ax.add_patch(rect)
        obj_class = np.argmax(features[node_n, :80])
        ax.text(x, y, class_names[obj_class], color='green')

    for node_n in range(len(features)):
        y, x, y2, x2 = features[node_n, 445:449]*1000
        center_n_y = (y+y2)/2
        center_n_x = (x+x2)/2
        for node_j in range(node_n, len(features)):
            y, x, y2, x2 = features[node_j, 445:449]*1000
            center_j_y = (y+y2)/2
            center_j_x = (x+x2)/2
            if node_n != node_j:
                # NOTE: Drawing top left object to right object and bottom right to left
                if center_n_x > center_j_x:
                    edge_val_top = adj[node_n, node_j]
                    edge_val_bot = adj[node_j, node_n]
                else:
                    edge_val_top = adj[node_j, node_n]
                    edge_val_bot = adj[node_n, node_j]

                ax.plot([center_n_x, center_j_x], [center_n_y, center_j_y], linewidth=edge_val)
                ax.text((center_n_x+center_j_x)/2, (center_n_y+center_j_y)/2, str("%.2f"%edge_val_top), color='blue')
                ax.text((center_n_x+center_j_x)/2, (center_n_y+center_j_y)/2-28, str("%.2f"%edge_val_bot), color='blue')
            else:
                edge_val = adj[node_n, node_j]
                ax.plot([center_n_x, center_j_x], [center_n_y, center_j_y], linewidth=edge_val)
                ax.text((center_n_x+center_j_x)/2, (center_n_y+center_j_y)/2, str("%.2f"%edge_val), color='red') # Own interaction values

    fig.canvas.draw()
    data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
    data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
    plt.close(fig)

    return data


def plot_context_kit(ax, features, adj):
    c = ['b', 'r', 'g', 'k', 'y', 'c', 'm', 'w']*1000

    adj = util.normalize(adj)
    #threshold = 10 # 10%

    # SHOW ONLY:
    showonly = 2
    adj -= np.eye(len(adj))
    threshold = adj.reshape(-1)[adj.reshape(-1).argsort()[-1*showonly]]
    threshold = max(0.01, threshold)

    for node_n in range(len(features)):
        x, y, z, x2, y2, z2 = features[node_n, :6]
        center_n_z = (z+z2)/2
        center_n_y = (y+y2)/2
        center_n_x = (x+x2)/2
        for node_j in range(node_n, len(features)):
            x, y, z, x2, y2, z2 = features[node_j, :6]
            center_j_z = (z+z2)/2
            center_j_y = (y+y2)/2
            center_j_x = (x+x2)/2
            if node_n != node_j:
                # NOTE: Drawing top left object to right object and bottom right to left
                edge_val_nj = adj[node_j, node_n].copy()
                edge_val_jn = adj[node_n, node_j].copy()

                if edge_val_jn >= threshold:
                    #ax.plot3D([center_n_x, center_j_x], [center_n_y, center_j_y], [center_n_z, center_j_z], linewidth=(edge_val_top+edge_val_bot)*0.03+0.5)
                    dist = np.sqrt((center_n_x-center_j_x)**2+(center_n_y-center_j_y)**2+(center_n_z-center_j_z)**2)
                    ax.quiver(center_j_x, center_j_y, center_j_z, center_n_x-center_j_x, center_n_y-center_j_y, center_n_z-center_j_z, color='green')
                    ax.text((center_n_x*0.8+center_j_x*0.2), (center_n_y*0.8+center_j_y*0.2), (center_n_z*0.8+center_j_z*0.2), str("%.2f"%(edge_val_jn*100)), color='blue')
                if edge_val_nj >= threshold:
                    #ax.plot3D([center_n_x, center_j_x], [center_n_y, center_j_y], [center_n_z, center_j_z], linewidth=(edge_val_top+edge_val_bot)*0.03+0.5)
                    dist = np.sqrt((center_n_x-center_j_x)**2+(center_n_y-center_j_y)**2+(center_n_z-center_j_z)**2)
                    ax.quiver(center_n_x, center_n_y, center_n_z, center_j_x-center_n_x, center_j_y-center_n_y, center_j_z-center_n_z, color='green')
                    ax.text((center_n_x*0.2+center_j_x*0.8), (center_n_y*0.2+center_j_y*0.8), (center_n_z*0.2+center_j_z*0.8), str("%.2f"%(edge_val_nj*100)), color='blue')
            else:
                edge_val = adj[node_n, node_j]*100
#                if edge_val > threshold:
#                    ax.plot3D([center_n_x, center_j_x], [center_n_y, center_j_y], [center_n_z, center_j_z], linewidth=edge_val) # This is just a point
#                    ax.text((center_n_x+center_j_x)/2, (center_n_y+center_j_y)/2, (center_n_z+center_j_z)/2, str("%.2f"%edge_val), color='red') # Own interaction values

    return

def plot_statistic(path, data, title):
#    mean = np.mean(data, 0)
#    std = np.std(data, 0)
    per90 = np.percentile(data, 90, 0)
    per80 = np.percentile(data, 80, 0)
    per60 = np.percentile(data, 60, 0)
    per50 = np.percentile(data, 50, 0)
    per40 = np.percentile(data, 40, 0)
    per20 = np.percentile(data, 20, 0)
    per10 = np.percentile(data, 10, 0)

    steps = len(per50) - 1 #First point is given initial interaction set at 0

    plt.figure()
    plt.title(title)
    plt.xlim(0, steps - 1)
    plt.ylim(0, 100)
    plt.ylabel('% Interaction')
    plt.xlabel('Time')

    plt.fill_between(x=np.arange(steps), y1=per10[1:]*100, y2=per90[1:]*100, alpha=0.2, color='b')
    plt.fill_between(x=np.arange(steps), y1=per20[1:]*100, y2=per80[1:]*100, alpha=0.2, color='b')
    plt.fill_between(x=np.arange(steps), y1=per40[1:]*100, y2=per60[1:]*100, alpha=0.2, color='b')
    plt.plot(per50[1:]*100, color='b')
    plt.savefig(path + '/' + title + '.png')

    return
