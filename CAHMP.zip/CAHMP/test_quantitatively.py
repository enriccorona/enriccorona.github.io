import time
import utils
from options.test_options import TestOptions
from data.custom_dataset_data_loader import CustomDatasetDataLoader
from models.models import ModelsFactory
from utils.tb_visualizer import TBVisualizer
from collections import OrderedDict
import os
import numpy as np


def show_res(array):
    print("Error in 0sec - 0.5sec:")
    print(np.mean(array[:5]))
    print("Error in 0.5sec - 1sec:")
    print(np.mean(array[5:10]))
    print("Error in 1sec - 1.5sec:")
    print(np.mean(array[10:15]))
    print("Error in 1.5sec - 2sec:")
    print(np.mean(array[15:]))


class Test:
    def __init__(self):

        self._opt = TestOptions().parse()
        #assert self._opt.load_epoch > 0, 'Use command --load_epoch to indicate the epoch you want to load - and choose a trained model'

        data_loader_test = CustomDatasetDataLoader(self._opt, mode='test')
        self._dataset_test = data_loader_test.load_data()
        self._dataset_test_size = len(data_loader_test)
        print('#test images = %d' % self._dataset_test_size)

        self._model = ModelsFactory.get_by_name(self._opt.model, self._opt)
        self._tb_visualizer = TBVisualizer(self._opt)

        self._total_steps = self._dataset_test_size
        self._display_visualizer_test(20, self._total_steps)

    def _display_visualizer_test(self, i_epoch, total_steps):
        test_start_time = time.time()
        threshold_visuals =-1

        # set model to eval
        self._model.set_eval()

        # evaluate self._opt.num_iters_validate epochs
        test_errors = OrderedDict()
        statistics = OrderedDict()
        iters = 0
        for i_test_batch, test_batch in enumerate(self._dataset_test):
            # evaluate model
            self._model.set_input(test_batch)
            self._model.forward(keep_data_for_visuals=(i_test_batch < threshold_visuals), obtain_errors=True)
            errors = self._model.get_current_errors()

            # store current batch errors
            for k, v in errors.items():
                if k in test_errors:
                    test_errors[k] += v
                else:
                    test_errors[k] = v

            if not 'baseline' in self._opt.model and not 'zerovelocity' in self._opt.model:
                stats = self._model.get_current_interaction_statistics()
                # store statistics data
                for k, v in stats.items():
                    if k in statistics:
                        statistics[k] += v
                    else:
                        statistics[k] = v

            iters += 1
            if (iters % 10) == 0:
                print(str(iters) + '/' + str(len(self._dataset_test)))

            if i_test_batch < threshold_visuals:
                self._tb_visualizer.display_current_results(self._model.get_current_visuals(), i_test_batch, is_train=False, save_visuals=True)

        # normalize errors
        for k in test_errors.keys():
            test_errors[k] /= iters

        # visualize
        t = (time.time() - test_start_time)
        
        print("Error in human motion prediction:")
        print(show_res(test_errors['loss_g_l2']))
        if 'loss_g_l2_objects' in test_errors.keys():
            print("Error in object motion prediction:")
            print(show_res(test_errors['loss_g_l2_objects']))


if __name__ == "__main__":
    Test()
