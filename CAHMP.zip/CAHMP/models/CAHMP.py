import torch
from collections import OrderedDict
from torch.autograd import Variable
import utils.util as util
import utils.plots as plot_utils
from .models import BaseModel
from networks.networks import NetworksFactory
import os
import numpy as np

class Model(BaseModel):
    def __init__(self, opt):
        super(Model, self).__init__(opt)
        #self._name = 'GANimation'
        self._name = 'gan_context'

        # create networks
        self._init_create_networks()

        # init train variables
        if self._is_train:
            self._init_train_vars()

        # load networks and optimizers
        if not self._is_train or self._opt.load_epoch > 0:
            self.load()

        # init
        self._init_losses()

    def _init_create_networks(self):
        # generator network
        self._G = self._create_generator()
        self._G.init_weights()
        self._G.cuda()

    def _create_generator(self):
        hidsize = 10

        if self._opt.dataset_mode == 'kit_lean':
            hidsize -= 1

        print("Graph model based on attention")
        hidsize_context = 256
        #hidsize_context = 64 #256

        rnn =  NetworksFactory.get_by_name('context_rnn', source_seq_len = self._opt.seq_length_in//self._opt.seq_step, target_seq_len=self._opt.seq_length_out//self._opt.seq_step, human_size=18*3, rnn_size=1024, num_layers=1, context_size=hidsize_context, nfeat=65, nhid=hidsize_context)

        return rnn

    def _init_train_vars(self):
        self._current_lr_G = self._opt.lr_G
        self._current_lr_graph_model = self._opt.lr_G

        # initialize optimizers
        self._optimizer_G = torch.optim.Adam(self._G.parameters(), lr=self._current_lr_G,
                                             betas=[self._opt.G_adam_b1, self._opt.G_adam_b2])

    def _init_losses(self):

        print("Creating losses")
        # init losses G
        self._loss_g_l2 = Variable(self._Tensor([0]))
        self._loss_g_l2_shortterm = Variable(self._Tensor([0]))
        self._loss_g_l2_longterm = Variable(self._Tensor([0]))
        self._loss_g_l2_objects = Variable(self._Tensor([0]))
        self._loss_g_l2_objects_shortterm = Variable(self._Tensor([0]))
        self._loss_g_l2_objects_longterm = Variable(self._Tensor([0]))


    def set_input(self, input):
        self._input_encoder_inputs = input['encoder_inputs']
        self._input_decoder_outputs = input['decoder_outputs']
        self._input_imgname = input['img_name']
        self._input_frame_beginning_sequence = input['frame_beginning_sequence']
        self._input_affected_nodes = input['affected_nodes']
        self._input_norm_std = input['norm']
        self._input_label_encoder_classes_ = input['label_encoder_classes_']

        self._input_features = input['features']
        self._input_future_features = input['features_future']
        self._input_objectclasses = input['objects']
        self._input_feature_sizes = input['feature_sizes']

    def set_train(self):
        self._G.train()
        self._is_train = True

    def set_eval(self):
        self._G.eval()
        self._is_train = False


    def forward(self, keep_data_for_visuals=False, obtain_errors=False):
        if not self._is_train:
            self._B = self._input_encoder_inputs.size(0)
            self._encoder_inputs = Variable(self._input_encoder_inputs.float())
            self._decoder_outputs = Variable(self._input_decoder_outputs.float())

            self._encoder_inputs = self._encoder_inputs.view([-1, self._opt.seq_length_in//self._opt.seq_step, 18*3])
            self._decoder_outputs = self._decoder_outputs.view([-1, self._opt.seq_length_out//self._opt.seq_step, 18*3])

            people_representations = []
            interactions_predicted = [] # Save adjacency matrices predicted for later visualization
            pred_reps = []
            num_samples = self._opt.seq_length_in//self._opt.seq_step
            num_future_samples = self._opt.seq_length_out//self._opt.seq_step
            # Loss variables:
            steps_shortterm = 50//self._opt.seq_step
            loss_g_l2 = Variable(self._Tensor([0]*20))
            loss_g_l2_shortterm = Variable(self._Tensor([0]))
            loss_g_l2_longterm = Variable(self._Tensor([0]))
            loss_g_l2_objects = Variable(self._Tensor([0]*20))
            loss_g_l2_objects_shortterm = Variable(self._Tensor([0]))
            loss_g_l2_objects_longterm = Variable(self._Tensor([0]))
            all_motions = []
            all_gts = []
            for i in range(self._B):
                size = self._input_feature_sizes[i]

                # Input and Output:
                inp_representations = torch.FloatTensor(self._input_features[i]).cuda().view([num_samples, size, -1])
                gt = torch.FloatTensor(self._input_future_features[i]).cuda()
                # People index:
                indxs = self._input_affected_nodes[i]
                whindxs = np.where(indxs)[0]
                
                # Forward pass
                motion_generated, pred_future_rep, adjs_pred = self._G(self._encoder_inputs[i], inp_representations, indxs)

                # Save adjacency matrices predicted for later visualization in MoCap scene
                interactions_predicted.append(adjs_pred)
                pred_reps.append(pred_future_rep)

                # Obtain L2 movement loss
                gt = torch.FloatTensor(self._input_future_features[i]).cuda()

                all_motions.append(motion_generated*self._input_norm_std[0])
                all_gts.append(gt[:, whindxs, -18*3:]*self._input_norm_std[0])

                # Obtain L2 loss
                sample_loss_g_l2 = (gt[:, whindxs, -18*3:]*self._input_norm_std[0] - motion_generated*self._input_norm_std[0])**2
                sample_loss_g_l2 = torch.sqrt(sample_loss_g_l2.view((-1, len(whindxs), 18, 3)).sum(-1))
                loss_g_l2 = loss_g_l2 + sample_loss_g_l2.mean((1, 2))
                loss_g_l2_shortterm = loss_g_l2_shortterm + sample_loss_g_l2[:steps_shortterm].mean()
                loss_g_l2_longterm = loss_g_l2_longterm + sample_loss_g_l2[steps_shortterm:].mean()

                # Obtain L2 Object loss
                sample_l2_objects = (gt[:,:,:6]*self._input_norm_std[0] - pred_future_rep[:,:,:6]*self._input_norm_std[0])**2
                sample_l2_objects = torch.sqrt(sample_l2_objects.view((-1, size, 2, 3)).sum(-1))
                loss_g_l2_objects = loss_g_l2_objects + sample_l2_objects.mean((1, 2))
                loss_g_l2_objects_shortterm = loss_g_l2_objects_shortterm + sample_l2_objects[:steps_shortterm].mean()
                loss_g_l2_objects_longterm = loss_g_l2_objects_longterm + sample_l2_objects[steps_shortterm:].mean()

            # L2 loss
            self._loss_g_l2 = loss_g_l2/self._B
            self._loss_g_l2_objects = loss_g_l2_objects/self._B
            self._loss_g_l2_objects_shortterm = loss_g_l2_objects_shortterm/self._B
            self._loss_g_l2_objects_longterm = loss_g_l2_objects_longterm/self._B
            self._loss_g_l2_shortterm = loss_g_l2_shortterm/self._B
            self._loss_g_l2_longterm = loss_g_l2_longterm/self._B

            # -1 for scenes with more than one person:
            all_motions = torch.stack(all_motions).view(self._B, 20, -1, 18, 3)
            all_gts = torch.stack(all_gts).view(self._B, 20, -1, 18, 3)

            all_motions = all_motions.permute(0, 2, 1, 3, 4)
            all_gts = all_gts.permute(0, 2, 1, 3, 4)

            imgs = None
            data = None

            self._interactions_predicted = np.array(interactions_predicted)
            self._pred_reps = pred_reps

            return

    def optimize_parameters(self, keep_data_for_visuals=False):
        if self._is_train:
            # convert tensor to variables
            self._B = self._input_encoder_inputs.size(0)
            self._encoder_inputs = Variable(self._input_encoder_inputs.float())
            self._decoder_outputs = Variable(self._input_decoder_outputs.float())

            self._encoder_inputs = self._encoder_inputs.view([-1, self._opt.seq_length_in//self._opt.seq_step, 18*3])
            self._decoder_outputs = self._decoder_outputs.view([-1, self._opt.seq_length_out//self._opt.seq_step, 18*3])

            loss_G = self._forward_G(keep_data_for_visuals)
            self._optimizer_G.zero_grad()
            loss_G.backward()
            self._optimizer_G.step()


    def _forward_G(self, keep_data_for_visuals):
        people_representations = []
        interactions_predicted = []

        pred_reps = []
        num_samples = self._opt.seq_length_in//self._opt.seq_step
        num_future_samples = self._opt.seq_length_out//self._opt.seq_step
        steps_shortterm = 50//self._opt.seq_step

        # Training loss variable
        loss_g_l2 = Variable(self._Tensor([0]))
        # Information variables
        loss_g_l2_shortterm = Variable(self._Tensor([0]))
        loss_g_l2_longterm = Variable(self._Tensor([0]))
        loss_g_l2_objects = Variable(self._Tensor([0]))

        # Graph has different size in each training sample. They don't fit in a pytorch tensor, so let's just run the forward pass for each sample and then join losses:
        for i in range(self._B):
            size = self._input_feature_sizes[i]

            # Input and Output:
            inp_representations = torch.FloatTensor(self._input_features[i]).cuda().view([num_samples, size, -1])
            gt = torch.FloatTensor(self._input_future_features[i]).cuda()

            # People index:
            indxs = self._input_affected_nodes[i]
            whindxs = np.where(indxs)[0]

            # Forward pass
            motion_generated, pred_future_rep, adjs_pred = self._G(self._encoder_inputs[i], inp_representations, indxs)

            # Save adjacency matrices predicted for later visualization in MoCap scene
            interactions_predicted.append(adjs_pred)
            pred_reps.append(pred_future_rep)

            # Obtain L2 loss
            sample_loss_g_l2 = (gt[:, whindxs, -18*3:] - motion_generated)**2
            loss_g_l2 = loss_g_l2 + sample_loss_g_l2.mean()
            loss_g_l2_shortterm = loss_g_l2_shortterm + sample_loss_g_l2[:steps_shortterm].mean()
            loss_g_l2_longterm = loss_g_l2_longterm + sample_loss_g_l2[steps_shortterm:].mean()

            # Obtain L2 Object loss
            loss_g_l2_objects = loss_g_l2_objects + ((gt[:,:,:6] - pred_future_rep[:,:,:6])**2).mean()

        # L2 loss
        self._loss_g_l2 = loss_g_l2*self._opt.lambda_G_l2/self._B
        self._loss_g_l2_objects = loss_g_l2_objects*self._opt.lambda_G_objL2/self._B
        self._loss_g_l2_shortterm = loss_g_l2_shortterm*self._opt.lambda_G_l2/self._B
        self._loss_g_l2_longterm = loss_g_l2_longterm*self._opt.lambda_G_l2/self._B

        self._interactions_predicted = np.array(interactions_predicted)
        self._pred_reps = pred_reps

        # combine losses
        return self._loss_g_l2 + self._loss_g_l2_objects

    def get_current_errors(self):
        loss_dict = OrderedDict([
                                 ('loss_g_l2', self._loss_g_l2.cpu().data.numpy()),
                                 ('loss_g_l2_shortterm', self._loss_g_l2_shortterm.cpu().data.numpy()),
                                 ('loss_g_l2_longterm', self._loss_g_l2_longterm.cpu().data.numpy()),
                                 ('loss_g_l2_objects', self._loss_g_l2_objects.cpu().data.numpy()),
                                 ('loss_g_l2_objects_shortterm', self._loss_g_l2_objects_shortterm.cpu().data.numpy()),
                                 ('loss_g_l2_objects_longterm', self._loss_g_l2_objects_longterm.cpu().data.numpy()),
        ])

        return loss_dict

    def get_current_scalars(self):
        return OrderedDict([('lr_G', self._current_lr_G)])

    def get_current_plotting_data(self, i_test_batch):
        np.save(self._opt.data_dir + self._opt.checkpoints_dir + '/3d_past_feats_' + str(i_test_batch) + '_.npy', self._input_features[0].copy()*self._input_norm_std[0])
        np.save(self._opt.data_dir + self._opt.checkpoints_dir + '/3d_real_future_feats_' + str(i_test_batch) + '_.npy', self._input_future_features[0].copy()*self._input_norm_std[0])
        np.save(self._opt.data_dir + self._opt.checkpoints_dir + '/3d_pred_future_feats_' + str(i_test_batch) + '_.npy', self._pred_reps[0].cpu().data.numpy()*self._input_norm_std[0])
        np.save(self._opt.data_dir + self._opt.checkpoints_dir + '/3d_predicted_adjs_' + str(i_test_batch) + '_.npy', self._interactions_predicted[0].cpu().data.numpy())
        return

    def get_current_visuals(self):
        # visuals return dictionary
        visuals = OrderedDict()

        num_samples = self._opt.seq_length_in//self._opt.seq_step
        videos = []
        unnorm_features = self._input_norm_std[0] # x, y, z, x, y, z
        for i in range(min(self._B, 2)):
            past_features = self._input_features[i]*unnorm_features
            future_features = self._pred_reps[i].cpu().data.numpy()*unnorm_features
            real_future_features = self._input_future_features[i]*unnorm_features

            if type(self._interactions_predicted[0]) is np.ndarray:
                adj = self._interactions_predicted[i]
            else:
                adj = self._interactions_predicted[i].cpu().data.numpy()

            if self._opt.human_bbox_type == 'add_all_joints':
                videos.append(plot_utils.plot_3d_allpredictions(past_features, future_features, real_future_features, adj))
            else:
                raise('error')

        visuals['2_3dinteractions'] = np.array(videos)

        unnorm_features = self._input_norm_std[0].tolist()*2 # x, y, z, x, y, z
        i = 0
        size = self._input_feature_sizes[i]
        past_features = self._input_features[i]*unnorm_features
        future_features = self._predadjs_pred_reps.cpu().data.numpy()*unnorm_features
        future_features = np.transpose(future_features, (1, 0, 2, 3))
        real_future_features = self._input_future_features[i]*unnorm_features

        video = plot_utils.plot_3d_bayesian_allpredictions(past_features, future_features, real_future_features, self._predadjs_interactions_predicted)

        visuals['3_predictions_predadjs'] = np.array(video[np.newaxis])

        return visuals

    def get_current_adj(self):
        futurefeats = self._input_future_features
        feats = self._input_features
        adjs = self._interactions_predicted
        return futurefeats, feats, adjs, self._input_norm_std[0]

    def get_current_interaction_statistics(self):
        # NOTE STATISTICS USED:
        # 1 - Human reaching object
        # 2 - Human having left object
        # 3 - Human moving accordingly with object
        # 4 - Human with respect with object that is far
        # 5 - Human and human

        interactions = self._interactions_predicted

        statistics = OrderedDict()
        reaching = []
        reaching2 = []
        havingleft = []
        havingleft2 = []
        moveobject = []
        moveobject2 = []
        farobject = []
        human2human = []
        humanown = []
        unnorm = self._input_norm_std[0]

        #from IPython import embed
        #embed()
        wrist_ids = [-30, -29, -28, -27, -26, -25]

        for i in range(self._B):
            wrists_humans = self._input_features[i][:, :, wrist_ids]
            ishuman = np.where(wrists_humans.std((0, 2)) > 0.01)[0]
            isobject = np.where(wrists_humans.std((0, 2)) < 0.01)[0]
            objtype = self._input_features[i][0,isobject,6:-18*3]

            # Check if human wrist is getting close to object
            for j in range(len(ishuman)):
                dist_l, dist_r = self.obtain_moving_distance(self._input_features[i][:, isobject, :6].copy()*unnorm, wrists_humans[:, ishuman[j]].copy()*unnorm)
                dists = np.array((dist_l, dist_r))
                left_or_right = np.argmin(dists[:, -1], 0)
                isapproaching = dists[left_or_right, -1, np.arange(len(isobject))] < 100 # Is closer than 0.2 meters already?
                isapproaching &= dists[left_or_right, 0, np.arange(len(isobject))] > 200 # It started further than 0.5 meters?
                objsapproaching = np.where(isapproaching)[0]
                for k in range(len(objsapproaching)):
                    reaching.append(interactions[i][:, ishuman[j], isobject[objsapproaching[k]]].cpu().data.numpy())
                    reaching2.append(interactions[i][:, isobject[objsapproaching[k]], ishuman[j]].cpu().data.numpy())

            # Check if human wrist is getting far from object
            for j in range(len(ishuman)):
                dist_l, dist_r = self.obtain_moving_distance(self._input_features[i][:, isobject, :6].copy()*unnorm, wrists_humans[:, ishuman[j]].copy()*unnorm)
                dists = np.array((dist_l, dist_r))
                left_or_right = np.argmin(dists[:, -1], 0)
                isleaving = dists[left_or_right, -1, np.arange(len(isobject))] > 200 # Is further than 0.5 meters already?
                isleaving &= dists[left_or_right, 0, np.arange(len(isobject))] < 100 # It started closer than 0.2 meters?
                objsleaving = np.where(isleaving)[0]
                for k in range(len(objsleaving)):
                    havingleft.append(interactions[i][:, ishuman[j], isobject[objsleaving[k]]].cpu().data.numpy())
                    havingleft2.append(interactions[i][:, isobject[objsleaving[k]], ishuman[j]].cpu().data.numpy())

            # Check if human is moving the object
            for j in range(len(ishuman)):
                dist_l, dist_r = self.obtain_moving_distance(self._input_features[i][:, isobject, :6].copy()*unnorm, wrists_humans[:, ishuman[j]].copy()*unnorm)
                dists = np.array((dist_l, dist_r))
                left_or_right = np.argmin(dists[:, -1], 0)
                isholding = dists[left_or_right, 0, np.arange(len(isobject))] < 80 # It started closer than 0.2 meters?
                objholding = np.where(isholding)[0]
                for k in range(len(objholding)):
                    moveobject.append(interactions[i][:, ishuman[j], isobject[objholding[k]]].cpu().data.numpy())
                    moveobject2.append(interactions[i][:,isobject[objholding[k]], ishuman[j]].cpu().data.numpy())

            # Check own human interaction depending of the movement/interaction with other objects
            for j in range(len(ishuman)):
                for k in range(len(objtype)):
                    class_ = self._input_label_encoder_classes_[0][np.where(objtype[k])[0][0]]
                    key = 'Human2'+ class_
                    key2 = class_ + '2Human'
                    if key not in statistics.keys():
                        statistics[key] = []
                        statistics[key2] = []
                    statistics[key2].append(interactions[i][:, ishuman[j], isobject[k]].cpu().data.numpy())
                    statistics[key].append(interactions[i][:, isobject[k], ishuman[j]].cpu().data.numpy())

            if len(ishuman) == 2:
                human2human.append(interactions[i][:, ishuman[0], ishuman[1]].cpu().data.numpy())
                human2human.append(interactions[i][:, ishuman[1], ishuman[0]].cpu().data.numpy())

            # Check if there is human-human interaction
            for j in range(len(ishuman)):
                humanown.append(interactions[i][:, ishuman[j], ishuman[j]].cpu().data.numpy())
            
        statistics['ReachingObject'] = reaching
        statistics['ReachingObject2'] = reaching2
        statistics['LeavingObject'] = havingleft
        statistics['LeavingObject2'] = havingleft2
        statistics['MovingObject'] = moveobject
        statistics['MovingObject2'] = moveobject2
        statistics['FarObject'] = farobject
        statistics['Human2Human'] = human2human
        statistics['HumanOwnInteraction'] = humanown

        return statistics

    def obtain_moving_distance(self, feats, wrists):
        bb_8vertices = np.array([[feats[:, :, 0], feats[:, :, 1], feats[:, :, 2]],
                                [feats[:, :, 3], feats[:, :, 1], feats[:, :, 2]],
                                [feats[:, :, 0], feats[:, :, 4], feats[:, :, 2]],
                                [feats[:, :, 0], feats[:, :, 1], feats[:, :, 5]],
                                [feats[:, :, 3], feats[:, :, 4], feats[:, :, 2]],
                                [feats[:, :, 3], feats[:, :, 1], feats[:, :, 5]],
                                [feats[:, :, 0], feats[:, :, 4], feats[:, :, 5]],
                                [feats[:, :, 3], feats[:, :, 4], feats[:, :, 5]]])

        bb_8vertices = np.transpose(bb_8vertices, (2, 3, 0, 1))

        left = wrists[:, np.newaxis, np.newaxis, :3]
        right = wrists[:, np.newaxis, np.newaxis, 3:]
        dist_l = np.sqrt(np.sum((bb_8vertices-left)**2, -1).min(-1))
        dist_r = np.sqrt(np.sum((bb_8vertices-right)**2, -1).min(-1))
        return dist_l, dist_r

    def save(self, label):
        # save networks
        self._save_network(self._G, 'G', label)

        # save optimizers
        self._save_optimizer(self._optimizer_G, 'G', label)

    def load(self):
        load_epoch = self._opt.load_epoch

        # load G
        self._load_network(self._G, 'G', load_epoch)

        if self._is_train:
            # load optimizers
            self._load_optimizer(self._optimizer_G, 'G', load_epoch)

    def update_learning_rate(self):
        # updated learning rate G
        lr_decay_G = self._opt.lr_G / self._opt.nepochs_decay

        self._current_lr_G -= lr_decay_G
        for param_group in self._optimizer_G.param_groups:
            param_group['lr'] = self._current_lr_G
        print('update G learning rate: %f -> %f' %  (self._current_lr_G + lr_decay_G, self._current_lr_G))
